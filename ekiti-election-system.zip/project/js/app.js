// ============================================================
//  js/app.js
//  Application bootstrap — shared utilities, screen router,
//  clock, global event listeners, init
// ============================================================

// ── SCREEN NAVIGATION ─────────────────────────────────────
function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nb').forEach(b => b.classList.remove('active'));
  document.getElementById(name + '-screen').classList.add('active');
  const idx  = ['dashboard', 'agent', 'results', 'security', 'reg'].indexOf(name);
  const btns = document.querySelectorAll('.nb');
  if (btns[idx]) btns[idx].classList.add('active');
  if (name === 'dashboard') initDashMap();
  if (name === 'results')   renderResults();
  if (name === 'security')  { renderSecLog(); updateSecStats(); }
}

// ── TOAST NOTIFICATIONS ───────────────────────────────────
function toast(msg, type = 'ok') {
  const icons = { ok: '✅', err: '❌', warn: '⚠️', info: 'ℹ️' };
  const t = document.createElement('div');
  t.className = 'toast' + (type !== 'ok' ? ' ' + type : '');
  t.innerHTML = `<span>${icons[type] || '✅'}</span><span>${msg}</span>`;
  document.getElementById('toast-c').appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

// ── CLOCK ─────────────────────────────────────────────────
setInterval(() => {
  const el = document.getElementById('clk');
  if (el) el.textContent = new Date().toTimeString().slice(0, 8);
}, 1000);

// ── CLOSE DROPDOWNS ON OUTSIDE CLICK ─────────────────────
document.addEventListener('click', e => {
  if (!e.target.closest('#r-pu-srch') && !e.target.closest('#r-pu-dd'))
    document.getElementById('r-pu-dd')?.classList.remove('open');
  if (!e.target.closest('#a-pu-srch') && !e.target.closest('#a-pu-dd'))
    document.getElementById('a-pu-dd')?.classList.remove('open');
});

// ── DEVTOOLS DETERRENCE ───────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && ['I','J','C'].includes(e.key))) {
    SEC.log('warn', 'DevTools open attempt detected', 'Possible inspection of secure system');
  }
});

// ── LIVE FEED SIMULATION ──────────────────────────────────
setInterval(() => {
  if (Math.random() > 0.65) {
    const u = ALL_POLLING_UNITS[Math.floor(Math.random() * ALL_POLLING_UNITS.length)];
    MOCK_FEED.unshift({ u: u.code, lga: u.lga, d: 'Agent activity detected', age: 'fn' });
    if (MOCK_FEED.length > 25) MOCK_FEED.pop();
    if (document.getElementById('dashboard-screen').classList.contains('active')) renderFeed();
  }
}, 9000);

// ── INIT ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  seedMockData();
  refreshDash();
  initDashMap();

  SEC.log('ok',   'System initialised — all modules loaded',
                  '905 polling units · 16 LGAs · Ekiti State Election System');
  SEC.log('ok',   'Encryption layer active',
                  'TLS 1.3 · FNV-1a hash chaining · Session token auth');
  SEC.log('ok',   'Security monitoring online',
                  'Brute-force · Rate limiting · Anomaly detection · Honeypots');
  SEC.log('info', 'Audit logging started', 'All events timestamped and chain-hashed');

  updateThreatBanner();
  updateSecStats();
});
