// ============================================================
//  js/results.js
//  Results form, evidence upload, submission, live results
//  screen rendering, dashboard rendering, security log UI
// ============================================================

let reportedResults  = {};
let evidenceDataUrl  = null;
let totalSubCount    = 0;

// ── SEED MOCK DATA (demo only) ────────────────────────────
function seedMockData() {
  ALL_POLLING_UNITS.slice(0, 65).forEach(u => {
    const tot = Math.floor(Math.random() * 850) + 200;
    let rem   = tot;
    const res = {};
    PARTIES.forEach((p, i) => {
      const share = i === PARTIES.length - 1 ? rem
        : i === 0 ? Math.min(rem, Math.floor(tot * (0.28 + Math.random() * 0.15)))
        : i === 1 ? Math.min(rem, Math.floor(tot * (0.20 + Math.random() * 0.12)))
        : Math.min(rem, Math.floor(tot * (0.02 + Math.random() * 0.07)));
      res[p.id] = Math.max(0, share);
      rem = Math.max(0, rem - share);
    });
    const minsAgo = Math.floor(Math.random() * 200);
    const d = new Date(); d.setMinutes(d.getMinutes() - minsAgo);
    reportedResults[u.code] = { ...u, results: res, time: d.toTimeString().slice(0,5), evidenceUrl: null, agentId: null, hash: null };
  });
}

// ── AGENT — POLLING UNIT PICKER ───────────────────────────
function filterAPU() {
  const lga = document.getElementById('a-lga-filt').value;
  const q   = document.getElementById('a-pu-srch').value.toLowerCase().trim();
  let list  = lga ? ALL_POLLING_UNITS.filter(u => u.lga === lga) : ALL_POLLING_UNITS;
  if (q) list = list.filter(u =>
    u.code.toLowerCase().includes(q) ||
    u.name.toLowerCase().includes(q) ||
    u.ward.toLowerCase().includes(q)
  );
  document.getElementById('pu-count').textContent = list.length + ' unit' + (list.length !== 1 ? 's' : '');
  const dd = document.getElementById('a-pu-dd');
  if (!q && !lga) { dd.classList.remove('open'); return; }
  if (!list.length) { dd.innerHTML = '<div class="pu-opt" style="color:var(--tm)">No units found</div>'; dd.classList.add('open'); return; }
  dd.innerHTML = list.slice(0, 60).map(u =>
    `<div class="pu-opt" onclick='selAPU(${JSON.stringify(u)})'>
      <div class="pu-code">${u.code}</div>
      <div class="pu-name">${u.name}</div>
      <div class="pu-meta">${u.ward} · ${u.lga}</div>
    </div>`
  ).join('');
  dd.classList.add('open');
}

function openAPUDD() { filterAPU(); }
function searchAPU() { filterAPU(); document.getElementById('a-pu-dd').classList.add('open'); }

function selAPU(u) {
  agentPU = u;
  document.getElementById('a-pu-srch').value     = u.code + ' — ' + u.name;
  document.getElementById('a-pu-dd').classList.remove('open');
  document.getElementById('unit-hdr').textContent = u.code;
  renderAgentPUSel(u);
  updateChain();
}

function renderAgentPUSel(u) {
  const el = document.getElementById('a-pu-sel');
  el.style.display = 'block';
  el.innerHTML = `<div class="pu-sel">
    <div class="pu-sel-code">${u.code}</div>
    <div class="pu-sel-name">${u.name}</div>
    <div class="pu-sel-meta">${u.ward} · ${u.lga} · ${u.lat.toFixed(5)}, ${u.lng.toFixed(5)}</div>
  </div>`;
}

// ── RESULTS ENTRY FORM ────────────────────────────────────
function buildResultsForm() {
  document.getElementById('rform').innerHTML = PARTIES.map(p => `
    <div class="rrow">
      <div class="rr-p">
        <div class="plog" style="background:${p.color}">${p.abbr.slice(0,2)}</div>
        <div><div class="pabbr">${p.abbr}</div><div class="pfull">${p.name}</div></div>
      </div>
      <input type="number" class="rr-inp" id="v-${p.id}" min="0" value="0" oninput="calcTotals()">
      <span class="rr-lbl">votes</span>
    </div>`).join('');
  calcTotals();
}

function calcTotals() {
  let tot = 0, maxV = 0, lead = null;
  PARTIES.forEach(p => {
    const v = parseInt(document.getElementById('v-' + p.id)?.value) || 0;
    tot += v;
    if (v > maxV) { maxV = v; lead = p; }
  });
  document.getElementById('tot-votes').textContent  = tot.toLocaleString();
  document.getElementById('lead-party').textContent = lead && maxV > 0 ? lead.abbr + ' (' + maxV.toLocaleString() + ')' : '—';
  updateChain();
}

function updateChain() {
  const votes = {};
  PARTIES.forEach(p => votes[p.id] = parseInt(document.getElementById('v-' + p.id)?.value) || 0);
  const h = SEC.hash({ votes, unit: agentPU?.code, agent: currentAgent?.id, t: Math.floor(Date.now() / 30000) });
  document.getElementById('chain-disp').textContent = 'Integrity hash: ' + h + ' · ' + new Date().toTimeString().slice(0,8);
  document.getElementById('chain-ind').textContent  = 'HASH: ' + h;
}

// ── EVIDENCE UPLOAD ───────────────────────────────────────
function handleEvidence() {
  const file = document.getElementById('ev-inp').files[0];
  if (!file) return;
  if (file.size > 10 * 1024 * 1024) return toast('File too large (max 10MB)', 'err');
  const reader = new FileReader();
  reader.onload = e => {
    evidenceDataUrl = e.target.result;
    if (file.type.startsWith('image/')) {
      document.getElementById('ev-thumb').src = evidenceDataUrl;
      document.getElementById('ev-thumb').classList.add('show');
    }
    document.getElementById('ev-up').classList.add('done');
    document.getElementById('ev-info').style.display  = 'block';
    document.getElementById('ev-filename').textContent = file.name + ' (' + Math.round(file.size / 1024) + 'KB)';
    toast('EC8A evidence uploaded', 'ok');
    SEC.log('ok', 'Evidence uploaded', 'Agent: ' + (currentAgent?.id || '?') + ' · ' + file.name);
  };
  reader.readAsDataURL(file);
}

// ── SUBMIT RESULTS ────────────────────────────────────────
function submitResults() {
  if (!currentAgent)    return;
  if (!agentPU)         return toast('Select a polling unit first', 'warn');
  if (pickedLat === null) return toast('Set your GPS location first', 'warn');
  if (!evidenceDataUrl) return toast('Upload the EC8A result sheet photo', 'warn');

  if (!SEC.activeSessions.has(currentAgent.tok)) {
    SEC.log('crit', 'Submission rejected — invalid session token', currentAgent.id);
    toast('Session expired — please login again', 'err');
    doLogout(); return;
  }

  const votes = {};
  let total   = 0;
  PARTIES.forEach(p => {
    const v = parseInt(document.getElementById('v-' + p.id)?.value) || 0;
    votes[p.id] = v; total += v;
  });
  if (total === 0) return toast('Enter vote counts before submitting', 'warn');

  const refId     = 'EK-' + SEC.hash({ id: currentAgent.id, unit: agentPU.code, ts: Date.now() });
  const entryHash = SEC.hash({ votes, unit: agentPU.code, agent: currentAgent.id });
  const now       = new Date();

  reportedResults[agentPU.code] = {
    ...agentPU,
    lat: pickedLat, lng: pickedLng,
    results: votes, time: now.toTimeString().slice(0, 5),
    evidenceUrl: evidenceDataUrl,
    agentId: currentAgent.id, agentName: currentAgent.name,
    party: currentAgent.party, refId, hash: entryHash,
  };

  totalSubCount++;
  document.getElementById('sb-subs').textContent = totalSubCount;
  document.getElementById('sub-log').innerHTML = `
    <div style="background:var(--gl);border:1px solid rgba(0,176,79,.2);border-radius:var(--r6);padding:7px 9px">
      <div style="font-weight:700;color:var(--gd);font-size:10px">✅ Submitted</div>
      <div style="font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--tm)">${refId.slice(0,18)}</div>
      <div style="font-size:9px;color:var(--tm)">${now.toTimeString().slice(0,8)}</div>
    </div>`;

  document.getElementById('sub-receipt').innerHTML = [
    ['Ref ID',      refId.slice(0, 20)],
    ['Unit',        agentPU.code],
    ['Agent',       currentAgent.id],
    ['Total Votes', total.toLocaleString()],
    ['GPS',         pickedLat.toFixed(5) + ', ' + pickedLng.toFixed(5)],
    ['Time',        now.toTimeString().slice(0, 8)],
    ['Hash',        entryHash],
  ].map(r => `<div class="rc-r"><span class="rc-l">${r[0]}</span><span class="rc-v">${r[1]}</span></div>`).join('');

  document.getElementById('agent-body').style.display = 'none';
  document.getElementById('suc-ov').classList.add('show');
  SEC.log('ok', 'Results submitted: ' + agentPU.code, 'Ref: ' + refId + ' · Votes: ' + total);
  refreshDash();
  toast('Results sealed and transmitted ✓', 'ok');
}

function resetForm() {
  document.getElementById('suc-ov').classList.remove('show');
  document.getElementById('agent-body').style.display = 'grid';
  buildResultsForm();
  evidenceDataUrl = null;
  document.getElementById('ev-thumb').classList.remove('show');
  document.getElementById('ev-up').classList.remove('done');
  document.getElementById('ev-info').style.display = 'none';
  document.getElementById('ev-inp').value = '';
}

// ── DASHBOARD ─────────────────────────────────────────────
const MOCK_FEED = [
  { u:'EKS/AD/0001', lga:'Ado Ekiti',  d:'Results transmitted — 842 votes counted',        age:'fn' },
  { u:'EKS/EE/0072', lga:'Ekiti East', d:'Agent EK-PDP-EE-0002 submitted EC8A results',    age:'fn' },
  { u:'EKS/IK/0387', lga:'Ikere',      d:'Evidence sheet verified and stored',              age:'fr' },
  { u:'EKS/IJ/0511', lga:'Ijero',      d:'Results uploaded — 612 votes counted',            age:'fr' },
  { u:'EKS/MB/0204', lga:'Moba',       d:'Agent connected — GPS confirmed',                 age:'fo' },
  { u:'EKS/OY/0301', lga:'Oye',        d:'Results pending — agent online',                  age:'fo' },
  { u:'EKS/GB/0150', lga:'Gbonyin',    d:'⚠️ Delayed — connectivity issue reported',       age:'fa' },
  { u:'EKS/EW/0070', lga:'Ekiti West', d:'Results transmitted — 791 votes counted',         age:'fo' },
];
let feedBase = Date.now();

function refreshDash() {
  const rep = Object.keys(reportedResults).length;
  const tot = Object.values(reportedResults).reduce((s, u) => s + Object.values(u.results || {}).reduce((a, b) => a + b, 0), 0);
  document.getElementById('st-rep').textContent    = rep;
  document.getElementById('st-votes').textContent  = tot.toLocaleString();
  document.getElementById('st-agents').textContent = SEC.activeSessions.size;
  document.getElementById('st-alerts').textContent = SEC.auditLog.filter(e => e.type === 'crit').length;
  document.getElementById('st-subs').textContent   = totalSubCount;
  document.getElementById('pct-bdg').textContent   = Math.round(rep / 905 * 100) + '% reported';
  renderPartyTable();
  renderFeed();
  renderAgentMon();
}

function renderPartyTable() {
  const tots = {};
  PARTIES.forEach(p => tots[p.id] = 0);
  Object.values(reportedResults).forEach(u => PARTIES.forEach(p => tots[p.id] += (u.results?.[p.id] || 0)));
  const grand  = Object.values(tots).reduce((s, v) => s + v, 0);
  const sorted = [...PARTIES].sort((a, b) => tots[b.id] - tots[a.id]);
  const tbl    = document.getElementById('rtbl');
  tbl.innerHTML = '<tr><th style="padding-left:12px">Party</th><th>Votes</th><th style="width:150px">Share</th><th>%</th></tr>';
  sorted.forEach((p, i) => {
    const v   = tots[p.id];
    const pct = grand > 0 ? (v / grand * 100).toFixed(1) : '0.0';
    const bw  = grand > 0 ? (v / grand * 100) : 0;
    const tr  = document.createElement('tr');
    tr.innerHTML = `
      <td><div style="display:flex;align-items:center;gap:6px;padding:0 4px">
        <div style="width:20px;height:20px;border-radius:3px;background:${p.color};display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:800;color:#fff;flex-shrink:0">${p.abbr.slice(0,2)}</div>
        <div><div style="font-weight:700;font-size:10px">${p.abbr}</div>
        ${i === 0 ? '<span style="font-size:8px;background:var(--gol);color:#7a5600;padding:1px 5px;border-radius:20px;font-weight:700">🏆 Leading</span>' : ''}</div>
      </div></td>
      <td style="font-family:\'JetBrains Mono\',monospace;font-weight:700;font-size:10px">${v.toLocaleString()}</td>
      <td><div style="background:var(--g100);height:4px;border-radius:2px;overflow:hidden">
        <div style="width:${bw}%;background:${p.color};height:100%;border-radius:2px;transition:width .6s"></div>
      </div></td>
      <td style="font-size:9px;color:var(--tm);font-weight:600">${pct}%</td>`;
    tbl.appendChild(tr);
  });
}

function renderFeed() {
  const list = document.getElementById('feed-list');
  list.innerHTML = '';
  MOCK_FEED.forEach((f, i) => {
    const d  = new Date(feedBase - i * 9 * 60000);
    const el = document.createElement('div');
    el.className = 'fi';
    el.innerHTML = `<div class="fdot ${f.age}"></div>
      <div style="flex:1"><div class="fu">${f.u} · ${f.lga}</div><div class="fd">${f.d}</div></div>
      <div class="ft">${d.toTimeString().slice(0,5)}</div>`;
    list.appendChild(el);
  });
  document.getElementById('feed-bdg').textContent = MOCK_FEED.length + ' updates';
}

function renderAgentMon() {
  const agents = [
    { name:'Taiwo Adeyemi',   unit:'EKS/AD/0001', party:'APC',  col:'#006B3F', st:'on',   lga:'Ado Ekiti'  },
    { name:'Funmi Olaoluwa',  unit:'EKS/EE/0072', party:'PDP',  col:'#E30A17', st:'on',   lga:'Ekiti East' },
    { name:'Kehinde Adesanya',unit:'EKS/IK/0387', party:'LP',   col:'#1A6FA8', st:'pend', lga:'Ikere'      },
    { name:'Bola Ogunleye',   unit:'EKS/IJ/0511', party:'NNPP', col:'#E8A020', st:'off',  lga:'Ijero'      },
    { name:'Tunde Ajayi',     unit:'EKS/MB/0204', party:'APC',  col:'#006B3F', st:'on',   lga:'Moba'       },
    { name:'Yemi Fasanya',    unit:'EKS/OY/0301', party:'SDP',  col:'#BF360C', st:'pend', lga:'Oye'        },
  ];
  document.getElementById('agent-mon').innerHTML = agents.map(a => {
    const init = a.name.split(' ').map(n => n[0]).join('');
    const sl   = a.st === 'on' ? 'Online' : a.st === 'pend' ? 'Connecting...' : 'Offline';
    const sc   = a.st === 'on' ? 'var(--g)' : a.st === 'pend' ? 'var(--gold)' : 'var(--g400)';
    return `<div class="ami">
      <div class="ami-av" style="background:${a.col}">${init}</div>
      <div style="flex:1"><div class="ami-nm">${a.name}</div><div class="ami-u">${a.unit} · ${a.party} · ${a.lga}</div></div>
      <div class="ami-s" style="color:${sc}"><div class="sdot ${a.st}"></div>${sl}</div>
    </div>`;
  }).join('');
}

// ── LIVE RESULTS SCREEN ───────────────────────────────────
function renderResults() {
  renderLGAChips();
  renderUnitCards('all');
}

function renderLGAChips() {
  const el  = document.getElementById('lga-chips');
  el.innerHTML = '';
  const all = document.createElement('button');
  all.className = 'chip active';
  all.textContent = 'All LGAs';
  all.onclick = () => { setChip(all); renderUnitCards('all'); };
  el.appendChild(all);
  [...new Set(Object.values(reportedResults).map(u => u.lga))].sort().forEach(lga => {
    const c = document.createElement('button');
    c.className = 'chip';
    c.textContent = lga;
    c.onclick = () => { setChip(c); renderUnitCards(lga); };
    el.appendChild(c);
  });
}

function setChip(chip) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  chip.classList.add('active');
}

function filterUnits() {
  const active = document.querySelector('.chip.active')?.textContent;
  renderUnitCards(active === 'All LGAs' ? 'all' : (active || 'all'));
}

function renderUnitCards(lgaFilter) {
  const grid = document.getElementById('unit-grid');
  grid.innerHTML = '';
  const q = (document.getElementById('u-srch')?.value || '').toLowerCase();
  const units = Object.values(reportedResults).filter(u => {
    const ml = lgaFilter === 'all' || u.lga === lgaFilter;
    const ms = !q || u.code.toLowerCase().includes(q) || u.name.toLowerCase().includes(q) || u.lga.toLowerCase().includes(q);
    return ml && ms;
  });
  if (!units.length) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:var(--tm);padding:30px;font-size:12px">No results match your filter.</div>';
    return;
  }
  units.forEach(u => {
    const tot    = Object.values(u.results || {}).reduce((s, v) => s + v, 0);
    const sorted = [...PARTIES].sort((a, b) => (u.results?.[b.id] || 0) - (u.results?.[a.id] || 0));
    const card   = document.createElement('div');
    card.className = 'ruc';
    card.innerHTML = `
      <div class="ruc-h">
        <div><div class="ruc-code">${u.code}</div>
        <div class="ruc-nm">${u.name} · ${u.ward || ''}</div>
        <div class="ruc-nm" style="color:var(--blue)">${u.lga}</div></div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px">
          <div class="ruc-time">${u.time}</div>
          ${u.evidenceUrl
            ? `<img class="ev-sm" src="${u.evidenceUrl}" alt="EC8A" onclick="openLB('${u.evidenceUrl}')" title="View EC8A sheet">`
            : '<span style="font-size:8px;color:var(--tm)">No image</span>'}
        </div>
      </div>
      <div class="ruc-b">
        ${sorted.slice(0, 6).map(p => {
          const v   = u.results?.[p.id] || 0;
          const pct = tot > 0 ? (v / tot * 100) : 0;
          return `<div class="mbr">
            <div class="mp" style="background:${p.color}">${p.abbr.slice(0,2)}</div>
            <div class="mbt"><div class="mbf" style="width:${pct}%;background:${p.color}"></div></div>
            <div class="mv">${v.toLocaleString()}</div>
          </div>`;
        }).join('')}
        <div style="margin-top:7px;padding-top:6px;border-top:1px solid var(--g100);display:flex;justify-content:space-between;font-size:9px;color:var(--tm)">
          <span>Total: <strong style="color:var(--tp)">${tot.toLocaleString()}</strong></span>
          <span style="color:${PARTY_COLORS[sorted[0]?.id]||'#000'};font-weight:700">${sorted[0]?.abbr || '—'} leading</span>
        </div>
        ${u.agentId ? `<div style="font-size:8px;color:var(--tm);margin-top:3px;font-family:'JetBrains Mono',monospace">Agent: ${u.agentId}</div>` : ''}
        ${u.hash ? `<div style="font-size:8px;color:var(--tm);margin-top:1px;font-family:'JetBrains Mono',monospace">Hash: ${u.hash}</div>` : ''}
      </div>`;
    grid.appendChild(card);
  });
}

function openLB(src) {
  document.getElementById('lb-img').src = src;
  document.getElementById('lightbox').classList.add('open');
}
function closeLightbox() { document.getElementById('lightbox').classList.remove('open'); }

// ── SECURITY SCREEN ───────────────────────────────────────
function renderSecLog() {
  const el = document.getElementById('sec-log');
  if (!el) return;
  el.innerHTML = SEC.auditLog.slice(0, 100).map(e => {
    const cls = e.type === 'crit' ? 'ev-c' : e.type === 'warn' ? 'ev-w' : e.type === 'ok' ? 'ev-k' : 'ev-i';
    const ic  = e.type === 'crit' ? '⛔' : e.type === 'warn' ? '⚠️' : e.type === 'ok' ? '✅' : 'ℹ️';
    return `<div class="sev">
      <div class="sev-ic ${cls}">${ic}</div>
      <div class="sev-msg">${e.msg}${e.detail ? '<br><span style="font-size:8px;opacity:.7">' + e.detail + '</span>' : ''}</div>
      <div class="sev-ts">${e.time}</div>
    </div>`;
  }).join('');
}

function updateSecStats() {
  document.getElementById('sec-sessions').textContent = SEC.activeSessions.size;
  document.getElementById('sec-blocked').textContent  = SEC.blockedSessions.length;
  document.getElementById('sec-failed').textContent   = SEC.attempts;
  document.getElementById('sec-events').textContent   = SEC.auditLog.length;
  const bb = document.getElementById('blocked-bdg');
  if (bb) bb.textContent = SEC.blockedSessions.length + ' blocked';
  renderBlockedList();
  renderThreatGauges();
}

function renderBlockedList() {
  const el = document.getElementById('blocked-list');
  if (!el) return;
  if (!SEC.blockedSessions.length) { el.innerHTML = '<div style="font-size:10px;color:var(--tm);text-align:center;padding:7px">No blocked sessions</div>'; return; }
  el.innerHTML = SEC.blockedSessions.map(s => `
    <div class="ip-item">
      <div><div class="ip-addr">${s.addr}</div><div class="ip-rsn">${s.reason}</div></div>
      <div class="ip-t">${s.time}</div>
    </div>`).join('');
}

function renderThreatGauges() {
  const el = document.getElementById('threat-gauges');
  if (!el) return;
  const gauges = [
    { label: 'Brute force risk',   val: Math.min(100, SEC.attempts * 20),                                         color: 'var(--red)' },
    { label: 'Login anomalies',    val: Math.min(100, SEC.auditLog.filter(e => e.type === 'warn').length * 12),   color: 'var(--ora)' },
    { label: 'Injection attempts', val: Math.min(100, SEC.auditLog.filter(e => e.msg.includes('njection')).length * 30), color: 'var(--pur)' },
    { label: 'System integrity',   val: 100,                                                                        color: 'var(--g)'   },
  ];
  el.innerHTML = gauges.map(g => `
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:10px;margin-bottom:3px">
        <span style="color:var(--ts)">${g.label}</span>
        <span style="font-family:'JetBrains Mono',monospace;font-weight:700;color:${g.color}">${g.val}%</span>
      </div>
      <div style="height:5px;background:var(--g100);border-radius:3px;overflow:hidden">
        <div style="height:100%;width:${g.val}%;background:${g.color};border-radius:3px;transition:width .5s"></div>
      </div>
    </div>`).join('');
}

function updateThreatBanner() {
  const banner = document.getElementById('threat-banner');
  const msg    = document.getElementById('threat-msg');
  const detail = document.getElementById('threat-detail');
  const secBar = document.getElementById('sec-bar');
  const secTxt = document.getElementById('sec-txt');
  const crit   = SEC.auditLog.filter(e => e.type === 'crit').length;

  if (SEC.attempts >= 4 || SEC.blockedSessions.length > 0 || crit >= 2) {
    banner.className = 'threat thr-crit';
    msg.textContent  = '🚨 HIGH THREAT — Attacks detected. System on high alert.';
    detail.textContent = SEC.blockedSessions.length + ' blocked · ' + SEC.attempts + ' failed logins';
    if (secBar) { secBar.style.background = 'rgba(192,57,43,.2)'; secBar.style.borderColor = 'rgba(192,57,43,.4)'; secBar.style.color = 'var(--red)'; }
    if (secTxt) secTxt.textContent = '⚠ Alert';
  } else if (SEC.attempts >= 2) {
    banner.className = 'threat thr-warn';
    msg.textContent  = '⚠️ ELEVATED — Multiple failed logins detected.';
    detail.textContent = SEC.attempts + '/5 attempts used';
    if (secBar) { secBar.style.background = 'rgba(230,126,34,.15)'; secBar.style.borderColor = 'rgba(230,126,34,.3)'; secBar.style.color = 'var(--ora)'; }
    if (secTxt) secTxt.textContent = '⚠ Warning';
  } else {
    banner.className = 'threat thr-ok';
    msg.textContent  = '✅ System secured — All connections encrypted · Monitoring active';
    detail.textContent = '';
    if (secBar) { secBar.style.background = 'rgba(0,176,79,.1)'; secBar.style.borderColor = 'rgba(0,176,79,.25)'; secBar.style.color = '#4ade80'; }
    if (secTxt) secTxt.textContent = 'Secure';
  }
}
