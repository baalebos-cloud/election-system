// ============================================================
//  js/data/polling-units.js
//  905 Ekiti State polling units across all 16 LGAs
//  Source: INEC Ekiti State polling unit register
// ============================================================

const ALL_POLLING_UNITS = [
  {
    "code": "EKS/AD/0001",
    "name": "Adebayo Market Square",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.591806,
    "lng": 5.240224
  },
  {
    "code": "EKS/AD/0002",
    "name": "Adebayo Council Hall",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.600757,
    "lng": 5.239818
  },
  {
    "code": "EKS/AD/0003",
    "name": "Adebayo Open Field",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.642153,
    "lng": 5.224529
  },
  {
    "code": "EKS/AD/0004",
    "name": "Adebayo Market Square",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.616654,
    "lng": 5.183284
  },
  {
    "code": "EKS/AD/0005",
    "name": "Adebayo Motor Park",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.601513,
    "lng": 5.229061
  },
  {
    "code": "EKS/AD/0006",
    "name": "Adebayo Motor Park",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.598807,
    "lng": 5.232891
  },
  {
    "code": "EKS/AD/0007",
    "name": "Adebayo Youth Centre",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.616462,
    "lng": 5.216837
  },
  {
    "code": "EKS/AD/0008",
    "name": "Adebayo Secondary School",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.647654,
    "lng": 5.18142
  },
  {
    "code": "EKS/AD/0009",
    "name": "Adebayo Youth Centre",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.595673,
    "lng": 5.214709
  },
  {
    "code": "EKS/AD/0010",
    "name": "Adebayo Palace Premises",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.595338,
    "lng": 5.257477
  },
  {
    "code": "EKS/AD/0011",
    "name": "Adebayo Palace Premises",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.591077,
    "lng": 5.211294
  },
  {
    "code": "EKS/AD/0012",
    "name": "Adebayo Secondary School",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.6507,
    "lng": 5.229198
  },
  {
    "code": "EKS/AD/0013",
    "name": "Adebayo Town Hall",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.586376,
    "lng": 5.217654
  },
  {
    "code": "EKS/AD/0014",
    "name": "Adebayo Motor Park",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.660749,
    "lng": 5.211183
  },
  {
    "code": "EKS/AD/0015",
    "name": "Adebayo Court Premises",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.606354,
    "lng": 5.231191
  },
  {
    "code": "EKS/AD/0016",
    "name": "Adebayo Ward Office",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.651837,
    "lng": 5.227088
  },
  {
    "code": "EKS/AD/0017",
    "name": "Adebayo Secondary School",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.588464,
    "lng": 5.233801
  },
  {
    "code": "EKS/AD/0018",
    "name": "Adebayo Market Square",
    "ward": "Adebayo",
    "lga": "Ado Ekiti",
    "lat": 7.606051,
    "lng": 5.187283
  },
  {
    "code": "EKS/AD/0019",
    "name": "Ajilosun Post Office",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.61331,
    "lng": 5.217173
  },
  {
    "code": "EKS/AD/0020",
    "name": "Ajilosun Market Square",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.612087,
    "lng": 5.210514
  },
  {
    "code": "EKS/AD/0021",
    "name": "Ajilosun Council Hall",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.636514,
    "lng": 5.237046
  },
  {
    "code": "EKS/AD/0022",
    "name": "Ajilosun Community Centre",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.634743,
    "lng": 5.22963
  },
  {
    "code": "EKS/AD/0023",
    "name": "Ajilosun Church Hall",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.625631,
    "lng": 5.200485
  },
  {
    "code": "EKS/AD/0024",
    "name": "Ajilosun Council Hall",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.613256,
    "lng": 5.260062
  },
  {
    "code": "EKS/AD/0025",
    "name": "Ajilosun Palace Premises",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.637953,
    "lng": 5.198469
  },
  {
    "code": "EKS/AD/0026",
    "name": "Ajilosun Market Square",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.650328,
    "lng": 5.24298
  },
  {
    "code": "EKS/AD/0027",
    "name": "Ajilosun Health Centre",
    "ward": "Ajilosun",
    "lga": "Ado Ekiti",
    "lat": 7.648644,
    "lng": 5.245304
  },
  {
    "code": "EKS/AD/0028",
    "name": "Basiri Open Field",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.588195,
    "lng": 5.253951
  },
  {
    "code": "EKS/AD/0029",
    "name": "Basiri Council Hall",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.653009,
    "lng": 5.206074
  },
  {
    "code": "EKS/AD/0030",
    "name": "Basiri Council Hall",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.622839,
    "lng": 5.251675
  },
  {
    "code": "EKS/AD/0031",
    "name": "Basiri Market Square",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.619608,
    "lng": 5.20209
  },
  {
    "code": "EKS/AD/0032",
    "name": "Basiri Ward Office",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.642499,
    "lng": 5.224018
  },
  {
    "code": "EKS/AD/0033",
    "name": "Basiri Health Centre",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.629667,
    "lng": 5.252726
  },
  {
    "code": "EKS/AD/0034",
    "name": "Basiri Community Centre",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.61186,
    "lng": 5.260686
  },
  {
    "code": "EKS/AD/0035",
    "name": "Basiri Primary School",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.623662,
    "lng": 5.188173
  },
  {
    "code": "EKS/AD/0036",
    "name": "Basiri Community Centre",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.651788,
    "lng": 5.193127
  },
  {
    "code": "EKS/AD/0037",
    "name": "Basiri Town Hall",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.646266,
    "lng": 5.214673
  },
  {
    "code": "EKS/AD/0038",
    "name": "Basiri Church Hall",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.613681,
    "lng": 5.228571
  },
  {
    "code": "EKS/AD/0039",
    "name": "Basiri Post Office",
    "ward": "Basiri",
    "lga": "Ado Ekiti",
    "lat": 7.625229,
    "lng": 5.258586
  },
  {
    "code": "EKS/AD/0040",
    "name": "Ekamefa Court Premises",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.637323,
    "lng": 5.190064
  },
  {
    "code": "EKS/AD/0041",
    "name": "Ekamefa Council Hall",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.625858,
    "lng": 5.202246
  },
  {
    "code": "EKS/AD/0042",
    "name": "Ekamefa Community Centre",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.610114,
    "lng": 5.20438
  },
  {
    "code": "EKS/AD/0043",
    "name": "Ekamefa Court Premises",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.619198,
    "lng": 5.257205
  },
  {
    "code": "EKS/AD/0044",
    "name": "Ekamefa Secondary School",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.640474,
    "lng": 5.258651
  },
  {
    "code": "EKS/AD/0045",
    "name": "Ekamefa Post Office",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.597192,
    "lng": 5.25391
  },
  {
    "code": "EKS/AD/0046",
    "name": "Ekamefa Motor Park",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.632924,
    "lng": 5.248234
  },
  {
    "code": "EKS/AD/0047",
    "name": "Ekamefa Secondary School",
    "ward": "Ekamefa",
    "lga": "Ado Ekiti",
    "lat": 7.631618,
    "lng": 5.193127
  },
  {
    "code": "EKS/AD/0048",
    "name": "Oke-Ila Motor Park",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.62605,
    "lng": 5.24319
  },
  {
    "code": "EKS/AD/0049",
    "name": "Oke-Ila Church Hall",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.656379,
    "lng": 5.228816
  },
  {
    "code": "EKS/AD/0050",
    "name": "Oke-Ila Court Premises",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.584458,
    "lng": 5.255228
  },
  {
    "code": "EKS/AD/0051",
    "name": "Oke-Ila Market Square",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.661726,
    "lng": 5.245442
  },
  {
    "code": "EKS/AD/0052",
    "name": "Oke-Ila Town Hall",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.587534,
    "lng": 5.251141
  },
  {
    "code": "EKS/AD/0053",
    "name": "Oke-Ila Town Hall",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.589752,
    "lng": 5.219779
  },
  {
    "code": "EKS/AD/0054",
    "name": "Oke-Ila Community Centre",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.661139,
    "lng": 5.223516
  },
  {
    "code": "EKS/AD/0055",
    "name": "Oke-Ila Motor Park",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.593171,
    "lng": 5.218923
  },
  {
    "code": "EKS/AD/0056",
    "name": "Oke-Ila Open Field",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.59611,
    "lng": 5.223114
  },
  {
    "code": "EKS/AD/0057",
    "name": "Oke-Ila Motor Park",
    "ward": "Oke-Ila",
    "lga": "Ado Ekiti",
    "lat": 7.616751,
    "lng": 5.197844
  },
  {
    "code": "EKS/AD/0058",
    "name": "Oke-Osun Council Hall",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.639936,
    "lng": 5.212819
  },
  {
    "code": "EKS/AD/0059",
    "name": "Oke-Osun Motor Park",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.63489,
    "lng": 5.215948
  },
  {
    "code": "EKS/AD/0060",
    "name": "Oke-Osun Town Hall",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.619019,
    "lng": 5.200732
  },
  {
    "code": "EKS/AD/0061",
    "name": "Oke-Osun Market Square",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.609947,
    "lng": 5.227965
  },
  {
    "code": "EKS/AD/0062",
    "name": "Oke-Osun Ward Office",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.629975,
    "lng": 5.181475
  },
  {
    "code": "EKS/AD/0063",
    "name": "Oke-Osun Court Premises",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.633388,
    "lng": 5.199215
  },
  {
    "code": "EKS/AD/0064",
    "name": "Oke-Osun Motor Park",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.585413,
    "lng": 5.207334
  },
  {
    "code": "EKS/AD/0065",
    "name": "Oke-Osun Market Square",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.60194,
    "lng": 5.234418
  },
  {
    "code": "EKS/AD/0066",
    "name": "Oke-Osun Court Premises",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.626039,
    "lng": 5.238768
  },
  {
    "code": "EKS/AD/0067",
    "name": "Oke-Osun Secondary School",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.628583,
    "lng": 5.218714
  },
  {
    "code": "EKS/AD/0068",
    "name": "Oke-Osun Town Hall",
    "ward": "Oke-Osun",
    "lga": "Ado Ekiti",
    "lat": 7.620738,
    "lng": 5.213465
  },
  {
    "code": "EKS/AD/0069",
    "name": "Ijigbo Health Centre",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.635619,
    "lng": 5.209244
  },
  {
    "code": "EKS/AD/0070",
    "name": "Ijigbo Council Hall",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.620262,
    "lng": 5.239226
  },
  {
    "code": "EKS/AD/0071",
    "name": "Ijigbo Primary School",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.635176,
    "lng": 5.232594
  },
  {
    "code": "EKS/AD/0072",
    "name": "Ijigbo Post Office",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.61511,
    "lng": 5.208044
  },
  {
    "code": "EKS/AD/0073",
    "name": "Ijigbo Motor Park",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.591642,
    "lng": 5.196227
  },
  {
    "code": "EKS/AD/0074",
    "name": "Ijigbo Youth Centre",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.618789,
    "lng": 5.214651
  },
  {
    "code": "EKS/AD/0075",
    "name": "Ijigbo Town Hall",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.61991,
    "lng": 5.250859
  },
  {
    "code": "EKS/AD/0076",
    "name": "Ijigbo Motor Park",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.61835,
    "lng": 5.249808
  },
  {
    "code": "EKS/AD/0077",
    "name": "Ijigbo Motor Park",
    "ward": "Ijigbo",
    "lga": "Ado Ekiti",
    "lat": 7.590733,
    "lng": 5.233072
  },
  {
    "code": "EKS/AD/0078",
    "name": "Irona Post Office",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.66042,
    "lng": 5.255009
  },
  {
    "code": "EKS/AD/0079",
    "name": "Irona Church Hall",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.60181,
    "lng": 5.213413
  },
  {
    "code": "EKS/AD/0080",
    "name": "Irona Primary School",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.6,
    "lng": 5.212983
  },
  {
    "code": "EKS/AD/0081",
    "name": "Irona Health Centre",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.596071,
    "lng": 5.181072
  },
  {
    "code": "EKS/AD/0082",
    "name": "Irona Church Hall",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.604116,
    "lng": 5.243626
  },
  {
    "code": "EKS/AD/0083",
    "name": "Irona Ward Office",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.60572,
    "lng": 5.236627
  },
  {
    "code": "EKS/AD/0084",
    "name": "Irona Ward Office",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.662534,
    "lng": 5.225361
  },
  {
    "code": "EKS/AD/0085",
    "name": "Irona Market Square",
    "ward": "Irona",
    "lga": "Ado Ekiti",
    "lat": 7.621834,
    "lng": 5.196092
  },
  {
    "code": "EKS/AD/0086",
    "name": "Okesa Ward Office",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.629234,
    "lng": 5.224276
  },
  {
    "code": "EKS/AD/0087",
    "name": "Okesa Church Hall",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.607988,
    "lng": 5.184911
  },
  {
    "code": "EKS/AD/0088",
    "name": "Okesa Community Centre",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.623128,
    "lng": 5.249118
  },
  {
    "code": "EKS/AD/0089",
    "name": "Okesa Post Office",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.58745,
    "lng": 5.221526
  },
  {
    "code": "EKS/AD/0090",
    "name": "Okesa Council Hall",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.597766,
    "lng": 5.228503
  },
  {
    "code": "EKS/AD/0091",
    "name": "Okesa Court Premises",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.651846,
    "lng": 5.213202
  },
  {
    "code": "EKS/AD/0092",
    "name": "Okesa Primary School",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.628474,
    "lng": 5.227214
  },
  {
    "code": "EKS/AD/0093",
    "name": "Okesa Open Field",
    "ward": "Okesa",
    "lga": "Ado Ekiti",
    "lat": 7.632451,
    "lng": 5.214438
  },
  {
    "code": "EKS/AD/0094",
    "name": "Oke-Odu Market Square",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.624723,
    "lng": 5.255677
  },
  {
    "code": "EKS/AD/0095",
    "name": "Oke-Odu Youth Centre",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.636478,
    "lng": 5.206035
  },
  {
    "code": "EKS/AD/0096",
    "name": "Oke-Odu Youth Centre",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.614563,
    "lng": 5.234635
  },
  {
    "code": "EKS/AD/0097",
    "name": "Oke-Odu Court Premises",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.619478,
    "lng": 5.255221
  },
  {
    "code": "EKS/AD/0098",
    "name": "Oke-Odu Open Field",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.588703,
    "lng": 5.217563
  },
  {
    "code": "EKS/AD/0099",
    "name": "Oke-Odu Market Square",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.662588,
    "lng": 5.186761
  },
  {
    "code": "EKS/AD/0100",
    "name": "Oke-Odu Palace Premises",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.623371,
    "lng": 5.191497
  },
  {
    "code": "EKS/AD/0101",
    "name": "Oke-Odu Palace Premises",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.653369,
    "lng": 5.251242
  },
  {
    "code": "EKS/AD/0102",
    "name": "Oke-Odu Motor Park",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.605699,
    "lng": 5.215955
  },
  {
    "code": "EKS/AD/0103",
    "name": "Oke-Odu Secondary School",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.639183,
    "lng": 5.229834
  },
  {
    "code": "EKS/AD/0104",
    "name": "Oke-Odu Post Office",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.635218,
    "lng": 5.181526
  },
  {
    "code": "EKS/AD/0105",
    "name": "Oke-Odu Town Hall",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.627268,
    "lng": 5.25544
  },
  {
    "code": "EKS/AD/0106",
    "name": "Oke-Odu Town Hall",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.658014,
    "lng": 5.191643
  },
  {
    "code": "EKS/AD/0107",
    "name": "Oke-Odu Community Centre",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.654077,
    "lng": 5.240293
  },
  {
    "code": "EKS/AD/0108",
    "name": "Oke-Odu Ward Office",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.604688,
    "lng": 5.229286
  },
  {
    "code": "EKS/AD/0109",
    "name": "Oke-Odu Post Office",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.61033,
    "lng": 5.2359
  },
  {
    "code": "EKS/AD/0110",
    "name": "Oke-Odu Court Premises",
    "ward": "Oke-Odu",
    "lga": "Ado Ekiti",
    "lat": 7.604019,
    "lng": 5.219983
  },
  {
    "code": "EKS/EE/0111",
    "name": "Ikere Ward 1 Youth Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.687484,
    "lng": 5.405886
  },
  {
    "code": "EKS/EE/0112",
    "name": "Ikere Ward 1 Community Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.683627,
    "lng": 5.398685
  },
  {
    "code": "EKS/EE/0113",
    "name": "Ikere Ward 1 Ward Office",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.731069,
    "lng": 5.392956
  },
  {
    "code": "EKS/EE/0114",
    "name": "Ikere Ward 1 Motor Park",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.715447,
    "lng": 5.428453
  },
  {
    "code": "EKS/EE/0115",
    "name": "Ikere Ward 1 Court Premises",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.680874,
    "lng": 5.37802
  },
  {
    "code": "EKS/EE/0116",
    "name": "Ikere Ward 1 Primary School",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.735382,
    "lng": 5.383924
  },
  {
    "code": "EKS/EE/0117",
    "name": "Ikere Ward 1 Community Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.746868,
    "lng": 5.418601
  },
  {
    "code": "EKS/EE/0118",
    "name": "Ikere Ward 1 Palace Premises",
    "ward": "Ikere Ward 1",
    "lga": "Ekiti East",
    "lat": 7.714483,
    "lng": 5.375346
  },
  {
    "code": "EKS/EE/0119",
    "name": "Ikere Ward 2 Market Square",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.752014,
    "lng": 5.388806
  },
  {
    "code": "EKS/EE/0120",
    "name": "Ikere Ward 2 Motor Park",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.733455,
    "lng": 5.400294
  },
  {
    "code": "EKS/EE/0121",
    "name": "Ikere Ward 2 Open Field",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.750831,
    "lng": 5.40451
  },
  {
    "code": "EKS/EE/0122",
    "name": "Ikere Ward 2 Market Square",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.740058,
    "lng": 5.446061
  },
  {
    "code": "EKS/EE/0123",
    "name": "Ikere Ward 2 Secondary School",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.749268,
    "lng": 5.450096
  },
  {
    "code": "EKS/EE/0124",
    "name": "Ikere Ward 2 Community Centre",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.694264,
    "lng": 5.404984
  },
  {
    "code": "EKS/EE/0125",
    "name": "Ikere Ward 2 Court Premises",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.739025,
    "lng": 5.398575
  },
  {
    "code": "EKS/EE/0126",
    "name": "Ikere Ward 2 Ward Office",
    "ward": "Ikere Ward 2",
    "lga": "Ekiti East",
    "lat": 7.713037,
    "lng": 5.425593
  },
  {
    "code": "EKS/EE/0127",
    "name": "Omuo Ward 1 Town Hall",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.701444,
    "lng": 5.43499
  },
  {
    "code": "EKS/EE/0128",
    "name": "Omuo Ward 1 Church Hall",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.710703,
    "lng": 5.375098
  },
  {
    "code": "EKS/EE/0129",
    "name": "Omuo Ward 1 Church Hall",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.697895,
    "lng": 5.437327
  },
  {
    "code": "EKS/EE/0130",
    "name": "Omuo Ward 1 Post Office",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.708073,
    "lng": 5.437643
  },
  {
    "code": "EKS/EE/0131",
    "name": "Omuo Ward 1 Market Square",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.698308,
    "lng": 5.373893
  },
  {
    "code": "EKS/EE/0132",
    "name": "Omuo Ward 1 Town Hall",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.711977,
    "lng": 5.394288
  },
  {
    "code": "EKS/EE/0133",
    "name": "Omuo Ward 1 Council Hall",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.757451,
    "lng": 5.39433
  },
  {
    "code": "EKS/EE/0134",
    "name": "Omuo Ward 1 Post Office",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.720852,
    "lng": 5.426361
  },
  {
    "code": "EKS/EE/0135",
    "name": "Omuo Ward 1 Town Hall",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.722997,
    "lng": 5.447139
  },
  {
    "code": "EKS/EE/0136",
    "name": "Omuo Ward 1 Open Field",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.750263,
    "lng": 5.392897
  },
  {
    "code": "EKS/EE/0137",
    "name": "Omuo Ward 1 Town Hall",
    "ward": "Omuo Ward 1",
    "lga": "Ekiti East",
    "lat": 7.757103,
    "lng": 5.393237
  },
  {
    "code": "EKS/EE/0138",
    "name": "Omuo Ward 2 Palace Premises",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.714865,
    "lng": 5.430284
  },
  {
    "code": "EKS/EE/0139",
    "name": "Omuo Ward 2 Town Hall",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.715012,
    "lng": 5.450739
  },
  {
    "code": "EKS/EE/0140",
    "name": "Omuo Ward 2 Youth Centre",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.710916,
    "lng": 5.418127
  },
  {
    "code": "EKS/EE/0141",
    "name": "Omuo Ward 2 Motor Park",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.683651,
    "lng": 5.406885
  },
  {
    "code": "EKS/EE/0142",
    "name": "Omuo Ward 2 Ward Office",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.754146,
    "lng": 5.415076
  },
  {
    "code": "EKS/EE/0143",
    "name": "Omuo Ward 2 Market Square",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.755321,
    "lng": 5.430963
  },
  {
    "code": "EKS/EE/0144",
    "name": "Omuo Ward 2 Council Hall",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.709238,
    "lng": 5.377598
  },
  {
    "code": "EKS/EE/0145",
    "name": "Omuo Ward 2 Council Hall",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.753762,
    "lng": 5.421852
  },
  {
    "code": "EKS/EE/0146",
    "name": "Omuo Ward 2 Youth Centre",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.747941,
    "lng": 5.42958
  },
  {
    "code": "EKS/EE/0147",
    "name": "Omuo Ward 2 Palace Premises",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.72067,
    "lng": 5.425351
  },
  {
    "code": "EKS/EE/0148",
    "name": "Omuo Ward 2 Community Centre",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.712292,
    "lng": 5.395652
  },
  {
    "code": "EKS/EE/0149",
    "name": "Omuo Ward 2 Health Centre",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.695447,
    "lng": 5.425194
  },
  {
    "code": "EKS/EE/0150",
    "name": "Omuo Ward 2 Open Field",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.734285,
    "lng": 5.444224
  },
  {
    "code": "EKS/EE/0151",
    "name": "Omuo Ward 2 Post Office",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.725628,
    "lng": 5.404486
  },
  {
    "code": "EKS/EE/0152",
    "name": "Omuo Ward 2 Health Centre",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.680132,
    "lng": 5.394953
  },
  {
    "code": "EKS/EE/0153",
    "name": "Omuo Ward 2 Palace Premises",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.742961,
    "lng": 5.420533
  },
  {
    "code": "EKS/EE/0154",
    "name": "Omuo Ward 2 Market Square",
    "ward": "Omuo Ward 2",
    "lga": "Ekiti East",
    "lat": 7.717299,
    "lng": 5.407373
  },
  {
    "code": "EKS/EE/0155",
    "name": "Iye Secondary School",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.717955,
    "lng": 5.444094
  },
  {
    "code": "EKS/EE/0156",
    "name": "Iye Youth Centre",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.738977,
    "lng": 5.424708
  },
  {
    "code": "EKS/EE/0157",
    "name": "Iye Palace Premises",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.721336,
    "lng": 5.422635
  },
  {
    "code": "EKS/EE/0158",
    "name": "Iye Market Square",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.687571,
    "lng": 5.44816
  },
  {
    "code": "EKS/EE/0159",
    "name": "Iye Market Square",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.733924,
    "lng": 5.389971
  },
  {
    "code": "EKS/EE/0160",
    "name": "Iye Church Hall",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.691888,
    "lng": 5.375697
  },
  {
    "code": "EKS/EE/0161",
    "name": "Iye Church Hall",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.729002,
    "lng": 5.433479
  },
  {
    "code": "EKS/EE/0162",
    "name": "Iye Market Square",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.713255,
    "lng": 5.422381
  },
  {
    "code": "EKS/EE/0163",
    "name": "Iye Health Centre",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.737568,
    "lng": 5.402718
  },
  {
    "code": "EKS/EE/0164",
    "name": "Iye Primary School",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.699619,
    "lng": 5.424485
  },
  {
    "code": "EKS/EE/0165",
    "name": "Iye Court Premises",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.751513,
    "lng": 5.440835
  },
  {
    "code": "EKS/EE/0166",
    "name": "Iye Community Centre",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.688627,
    "lng": 5.406012
  },
  {
    "code": "EKS/EE/0167",
    "name": "Iye Church Hall",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.744429,
    "lng": 5.427673
  },
  {
    "code": "EKS/EE/0168",
    "name": "Iye Post Office",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.684117,
    "lng": 5.391936
  },
  {
    "code": "EKS/EE/0169",
    "name": "Iye Church Hall",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.689809,
    "lng": 5.382667
  },
  {
    "code": "EKS/EE/0170",
    "name": "Iye Open Field",
    "ward": "Iye",
    "lga": "Ekiti East",
    "lat": 7.733506,
    "lng": 5.451031
  },
  {
    "code": "EKS/EE/0171",
    "name": "Ara Open Field",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.756103,
    "lng": 5.443314
  },
  {
    "code": "EKS/EE/0172",
    "name": "Ara Health Centre",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.745301,
    "lng": 5.443362
  },
  {
    "code": "EKS/EE/0173",
    "name": "Ara Court Premises",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.746546,
    "lng": 5.41583
  },
  {
    "code": "EKS/EE/0174",
    "name": "Ara Church Hall",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.692833,
    "lng": 5.44092
  },
  {
    "code": "EKS/EE/0175",
    "name": "Ara Council Hall",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.700835,
    "lng": 5.391779
  },
  {
    "code": "EKS/EE/0176",
    "name": "Ara Church Hall",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.702285,
    "lng": 5.434214
  },
  {
    "code": "EKS/EE/0177",
    "name": "Ara Town Hall",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.73024,
    "lng": 5.393968
  },
  {
    "code": "EKS/EE/0178",
    "name": "Ara Palace Premises",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.737184,
    "lng": 5.390759
  },
  {
    "code": "EKS/EE/0179",
    "name": "Ara Community Centre",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.705677,
    "lng": 5.415212
  },
  {
    "code": "EKS/EE/0180",
    "name": "Ara Community Centre",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.692166,
    "lng": 5.402643
  },
  {
    "code": "EKS/EE/0181",
    "name": "Ara Health Centre",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.736614,
    "lng": 5.377138
  },
  {
    "code": "EKS/EE/0182",
    "name": "Ara Primary School",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.706571,
    "lng": 5.409274
  },
  {
    "code": "EKS/EE/0183",
    "name": "Ara Court Premises",
    "ward": "Ara",
    "lga": "Ekiti East",
    "lat": 7.696647,
    "lng": 5.405611
  },
  {
    "code": "EKS/ES/0184",
    "name": "Ilawe Ward 1 Court Premises",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.585685,
    "lng": 5.141563
  },
  {
    "code": "EKS/ES/0185",
    "name": "Ilawe Ward 1 Primary School",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.571248,
    "lng": 5.17043
  },
  {
    "code": "EKS/ES/0186",
    "name": "Ilawe Ward 1 Health Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.585419,
    "lng": 5.163889
  },
  {
    "code": "EKS/ES/0187",
    "name": "Ilawe Ward 1 Health Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.578276,
    "lng": 5.216274
  },
  {
    "code": "EKS/ES/0188",
    "name": "Ilawe Ward 1 Secondary School",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.553058,
    "lng": 5.198771
  },
  {
    "code": "EKS/ES/0189",
    "name": "Ilawe Ward 1 Market Square",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.55826,
    "lng": 5.157643
  },
  {
    "code": "EKS/ES/0190",
    "name": "Ilawe Ward 1 Health Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.531835,
    "lng": 5.178851
  },
  {
    "code": "EKS/ES/0191",
    "name": "Ilawe Ward 1 Health Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.53689,
    "lng": 5.194331
  },
  {
    "code": "EKS/ES/0192",
    "name": "Ilawe Ward 1 Court Premises",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.567935,
    "lng": 5.20724
  },
  {
    "code": "EKS/ES/0193",
    "name": "Ilawe Ward 1 Primary School",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.52021,
    "lng": 5.189781
  },
  {
    "code": "EKS/ES/0194",
    "name": "Ilawe Ward 1 Council Hall",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.582554,
    "lng": 5.187351
  },
  {
    "code": "EKS/ES/0195",
    "name": "Ilawe Ward 1 Community Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.512168,
    "lng": 5.19142
  },
  {
    "code": "EKS/ES/0196",
    "name": "Ilawe Ward 1 Youth Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.579348,
    "lng": 5.154538
  },
  {
    "code": "EKS/ES/0197",
    "name": "Ilawe Ward 1 Palace Premises",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.540328,
    "lng": 5.156933
  },
  {
    "code": "EKS/ES/0198",
    "name": "Ilawe Ward 1 Youth Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.537,
    "lng": 5.210371
  },
  {
    "code": "EKS/ES/0199",
    "name": "Ilawe Ward 1 Youth Centre",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.570161,
    "lng": 5.206554
  },
  {
    "code": "EKS/ES/0200",
    "name": "Ilawe Ward 1 Ward Office",
    "ward": "Ilawe Ward 1",
    "lga": "Ekiti South West",
    "lat": 7.576793,
    "lng": 5.177625
  },
  {
    "code": "EKS/ES/0201",
    "name": "Ilawe Ward 2 Market Square",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.514167,
    "lng": 5.216154
  },
  {
    "code": "EKS/ES/0202",
    "name": "Ilawe Ward 2 Council Hall",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.562012,
    "lng": 5.202499
  },
  {
    "code": "EKS/ES/0203",
    "name": "Ilawe Ward 2 Market Square",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.513221,
    "lng": 5.142482
  },
  {
    "code": "EKS/ES/0204",
    "name": "Ilawe Ward 2 Community Centre",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.525949,
    "lng": 5.14163
  },
  {
    "code": "EKS/ES/0205",
    "name": "Ilawe Ward 2 Town Hall",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.529084,
    "lng": 5.177885
  },
  {
    "code": "EKS/ES/0206",
    "name": "Ilawe Ward 2 Ward Office",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.555118,
    "lng": 5.157437
  },
  {
    "code": "EKS/ES/0207",
    "name": "Ilawe Ward 2 Open Field",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.530499,
    "lng": 5.169512
  },
  {
    "code": "EKS/ES/0208",
    "name": "Ilawe Ward 2 Town Hall",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.55858,
    "lng": 5.199834
  },
  {
    "code": "EKS/ES/0209",
    "name": "Ilawe Ward 2 Youth Centre",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.572223,
    "lng": 5.153101
  },
  {
    "code": "EKS/ES/0210",
    "name": "Ilawe Ward 2 Youth Centre",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.518648,
    "lng": 5.142054
  },
  {
    "code": "EKS/ES/0211",
    "name": "Ilawe Ward 2 Health Centre",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.556064,
    "lng": 5.212642
  },
  {
    "code": "EKS/ES/0212",
    "name": "Ilawe Ward 2 Town Hall",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.541732,
    "lng": 5.197201
  },
  {
    "code": "EKS/ES/0213",
    "name": "Ilawe Ward 2 Market Square",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.557368,
    "lng": 5.206446
  },
  {
    "code": "EKS/ES/0214",
    "name": "Ilawe Ward 2 Post Office",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.518152,
    "lng": 5.201798
  },
  {
    "code": "EKS/ES/0215",
    "name": "Ilawe Ward 2 Secondary School",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.564741,
    "lng": 5.204442
  },
  {
    "code": "EKS/ES/0216",
    "name": "Ilawe Ward 2 Palace Premises",
    "ward": "Ilawe Ward 2",
    "lga": "Ekiti South West",
    "lat": 7.588708,
    "lng": 5.202611
  },
  {
    "code": "EKS/ES/0217",
    "name": "Igbara-Odo Motor Park",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.54427,
    "lng": 5.169646
  },
  {
    "code": "EKS/ES/0218",
    "name": "Igbara-Odo Health Centre",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.561803,
    "lng": 5.141012
  },
  {
    "code": "EKS/ES/0219",
    "name": "Igbara-Odo Palace Premises",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.575786,
    "lng": 5.148443
  },
  {
    "code": "EKS/ES/0220",
    "name": "Igbara-Odo Ward Office",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.560847,
    "lng": 5.206297
  },
  {
    "code": "EKS/ES/0221",
    "name": "Igbara-Odo Motor Park",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.522239,
    "lng": 5.154091
  },
  {
    "code": "EKS/ES/0222",
    "name": "Igbara-Odo Secondary School",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.587238,
    "lng": 5.161607
  },
  {
    "code": "EKS/ES/0223",
    "name": "Igbara-Odo Church Hall",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.583569,
    "lng": 5.201971
  },
  {
    "code": "EKS/ES/0224",
    "name": "Igbara-Odo Youth Centre",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.544846,
    "lng": 5.198482
  },
  {
    "code": "EKS/ES/0225",
    "name": "Igbara-Odo Court Premises",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.535784,
    "lng": 5.15964
  },
  {
    "code": "EKS/ES/0226",
    "name": "Igbara-Odo Market Square",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.516933,
    "lng": 5.21053
  },
  {
    "code": "EKS/ES/0227",
    "name": "Igbara-Odo Council Hall",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.570038,
    "lng": 5.185588
  },
  {
    "code": "EKS/ES/0228",
    "name": "Igbara-Odo Post Office",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.540319,
    "lng": 5.142296
  },
  {
    "code": "EKS/ES/0229",
    "name": "Igbara-Odo Palace Premises",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.536001,
    "lng": 5.179004
  },
  {
    "code": "EKS/ES/0230",
    "name": "Igbara-Odo Court Premises",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.573827,
    "lng": 5.167227
  },
  {
    "code": "EKS/ES/0231",
    "name": "Igbara-Odo Motor Park",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.557692,
    "lng": 5.210409
  },
  {
    "code": "EKS/ES/0232",
    "name": "Igbara-Odo Town Hall",
    "ward": "Igbara-Odo",
    "lga": "Ekiti South West",
    "lat": 7.510812,
    "lng": 5.215845
  },
  {
    "code": "EKS/ES/0233",
    "name": "Oke-Ila Secondary School",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.567606,
    "lng": 5.179086
  },
  {
    "code": "EKS/ES/0234",
    "name": "Oke-Ila Ward Office",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.529226,
    "lng": 5.178087
  },
  {
    "code": "EKS/ES/0235",
    "name": "Oke-Ila Town Hall",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.549266,
    "lng": 5.203435
  },
  {
    "code": "EKS/ES/0236",
    "name": "Oke-Ila Market Square",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.533539,
    "lng": 5.172352
  },
  {
    "code": "EKS/ES/0237",
    "name": "Oke-Ila Church Hall",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.534496,
    "lng": 5.186524
  },
  {
    "code": "EKS/ES/0238",
    "name": "Oke-Ila Ward Office",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.554278,
    "lng": 5.167501
  },
  {
    "code": "EKS/ES/0239",
    "name": "Oke-Ila Church Hall",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.554031,
    "lng": 5.168145
  },
  {
    "code": "EKS/ES/0240",
    "name": "Oke-Ila Town Hall",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.531673,
    "lng": 5.160112
  },
  {
    "code": "EKS/ES/0241",
    "name": "Oke-Ila Ward Office",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.567703,
    "lng": 5.165244
  },
  {
    "code": "EKS/ES/0242",
    "name": "Oke-Ila Community Centre",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.552869,
    "lng": 5.200975
  },
  {
    "code": "EKS/ES/0243",
    "name": "Oke-Ila Youth Centre",
    "ward": "Oke-Ila",
    "lga": "Ekiti South West",
    "lat": 7.525323,
    "lng": 5.199088
  },
  {
    "code": "EKS/EW/0244",
    "name": "Aramoko Youth Centre",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.718129,
    "lng": 5.061971
  },
  {
    "code": "EKS/EW/0245",
    "name": "Aramoko Youth Centre",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.718441,
    "lng": 5.08661
  },
  {
    "code": "EKS/EW/0246",
    "name": "Aramoko Primary School",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.658199,
    "lng": 5.034355
  },
  {
    "code": "EKS/EW/0247",
    "name": "Aramoko Primary School",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.696641,
    "lng": 5.030127
  },
  {
    "code": "EKS/EW/0248",
    "name": "Aramoko Ward Office",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.717944,
    "lng": 5.064269
  },
  {
    "code": "EKS/EW/0249",
    "name": "Aramoko Secondary School",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.715527,
    "lng": 5.07103
  },
  {
    "code": "EKS/EW/0250",
    "name": "Aramoko Open Field",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.67927,
    "lng": 5.089818
  },
  {
    "code": "EKS/EW/0251",
    "name": "Aramoko Palace Premises",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.662747,
    "lng": 5.058297
  },
  {
    "code": "EKS/EW/0252",
    "name": "Aramoko Post Office",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.654749,
    "lng": 5.02411
  },
  {
    "code": "EKS/EW/0253",
    "name": "Aramoko Health Centre",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.678218,
    "lng": 5.085769
  },
  {
    "code": "EKS/EW/0254",
    "name": "Aramoko Council Hall",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.67934,
    "lng": 5.066162
  },
  {
    "code": "EKS/EW/0255",
    "name": "Aramoko Open Field",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.644289,
    "lng": 5.031936
  },
  {
    "code": "EKS/EW/0256",
    "name": "Aramoko Market Square",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.71593,
    "lng": 5.026814
  },
  {
    "code": "EKS/EW/0257",
    "name": "Aramoko Open Field",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.649476,
    "lng": 5.081155
  },
  {
    "code": "EKS/EW/0258",
    "name": "Aramoko Secondary School",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.68769,
    "lng": 5.069473
  },
  {
    "code": "EKS/EW/0259",
    "name": "Aramoko Church Hall",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.681806,
    "lng": 5.056041
  },
  {
    "code": "EKS/EW/0260",
    "name": "Aramoko Health Centre",
    "ward": "Aramoko",
    "lga": "Ekiti West",
    "lat": 7.663788,
    "lng": 5.067082
  },
  {
    "code": "EKS/EW/0261",
    "name": "Ado Ward Ward Office",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.68549,
    "lng": 5.024818
  },
  {
    "code": "EKS/EW/0262",
    "name": "Ado Ward Council Hall",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.647939,
    "lng": 5.081019
  },
  {
    "code": "EKS/EW/0263",
    "name": "Ado Ward Community Centre",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.656882,
    "lng": 5.072834
  },
  {
    "code": "EKS/EW/0264",
    "name": "Ado Ward Community Centre",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.659189,
    "lng": 5.064159
  },
  {
    "code": "EKS/EW/0265",
    "name": "Ado Ward Open Field",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.640214,
    "lng": 5.05604
  },
  {
    "code": "EKS/EW/0266",
    "name": "Ado Ward Youth Centre",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.677593,
    "lng": 5.022611
  },
  {
    "code": "EKS/EW/0267",
    "name": "Ado Ward Church Hall",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.696556,
    "lng": 5.076239
  },
  {
    "code": "EKS/EW/0268",
    "name": "Ado Ward Youth Centre",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.645694,
    "lng": 5.038674
  },
  {
    "code": "EKS/EW/0269",
    "name": "Ado Ward Council Hall",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.703026,
    "lng": 5.070005
  },
  {
    "code": "EKS/EW/0270",
    "name": "Ado Ward Town Hall",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.704312,
    "lng": 5.035826
  },
  {
    "code": "EKS/EW/0271",
    "name": "Ado Ward Court Premises",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.683565,
    "lng": 5.071811
  },
  {
    "code": "EKS/EW/0272",
    "name": "Ado Ward Primary School",
    "ward": "Ado Ward",
    "lga": "Ekiti West",
    "lat": 7.661251,
    "lng": 5.031379
  },
  {
    "code": "EKS/EW/0273",
    "name": "Efon Ward 1 Post Office",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.70341,
    "lng": 5.067604
  },
  {
    "code": "EKS/EW/0274",
    "name": "Efon Ward 1 Town Hall",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.685537,
    "lng": 5.043089
  },
  {
    "code": "EKS/EW/0275",
    "name": "Efon Ward 1 Health Centre",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.677496,
    "lng": 5.044327
  },
  {
    "code": "EKS/EW/0276",
    "name": "Efon Ward 1 Church Hall",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.715414,
    "lng": 5.060038
  },
  {
    "code": "EKS/EW/0277",
    "name": "Efon Ward 1 Court Premises",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.675021,
    "lng": 5.067843
  },
  {
    "code": "EKS/EW/0278",
    "name": "Efon Ward 1 Youth Centre",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.674562,
    "lng": 5.045786
  },
  {
    "code": "EKS/EW/0279",
    "name": "Efon Ward 1 Council Hall",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.642069,
    "lng": 5.038314
  },
  {
    "code": "EKS/EW/0280",
    "name": "Efon Ward 1 Primary School",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.706877,
    "lng": 5.066016
  },
  {
    "code": "EKS/EW/0281",
    "name": "Efon Ward 1 Youth Centre",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.719966,
    "lng": 5.073783
  },
  {
    "code": "EKS/EW/0282",
    "name": "Efon Ward 1 Community Centre",
    "ward": "Efon Ward 1",
    "lga": "Ekiti West",
    "lat": 7.6861,
    "lng": 5.081049
  },
  {
    "code": "EKS/EW/0283",
    "name": "Efon Ward 2 Youth Centre",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.681517,
    "lng": 5.055378
  },
  {
    "code": "EKS/EW/0284",
    "name": "Efon Ward 2 Council Hall",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.654519,
    "lng": 5.066826
  },
  {
    "code": "EKS/EW/0285",
    "name": "Efon Ward 2 Church Hall",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.70514,
    "lng": 5.097524
  },
  {
    "code": "EKS/EW/0286",
    "name": "Efon Ward 2 Council Hall",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.667837,
    "lng": 5.046665
  },
  {
    "code": "EKS/EW/0287",
    "name": "Efon Ward 2 Health Centre",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.648368,
    "lng": 5.032866
  },
  {
    "code": "EKS/EW/0288",
    "name": "Efon Ward 2 Health Centre",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.695494,
    "lng": 5.043057
  },
  {
    "code": "EKS/EW/0289",
    "name": "Efon Ward 2 Church Hall",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.705085,
    "lng": 5.064008
  },
  {
    "code": "EKS/EW/0290",
    "name": "Efon Ward 2 Town Hall",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.647045,
    "lng": 5.040192
  },
  {
    "code": "EKS/EW/0291",
    "name": "Efon Ward 2 Motor Park",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.717615,
    "lng": 5.052334
  },
  {
    "code": "EKS/EW/0292",
    "name": "Efon Ward 2 Post Office",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.705994,
    "lng": 5.020092
  },
  {
    "code": "EKS/EW/0293",
    "name": "Efon Ward 2 Market Square",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.683407,
    "lng": 5.05306
  },
  {
    "code": "EKS/EW/0294",
    "name": "Efon Ward 2 Church Hall",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.681475,
    "lng": 5.069811
  },
  {
    "code": "EKS/EW/0295",
    "name": "Efon Ward 2 Market Square",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.690033,
    "lng": 5.080799
  },
  {
    "code": "EKS/EW/0296",
    "name": "Efon Ward 2 Youth Centre",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.661364,
    "lng": 5.030481
  },
  {
    "code": "EKS/EW/0297",
    "name": "Efon Ward 2 Town Hall",
    "ward": "Efon Ward 2",
    "lga": "Ekiti West",
    "lat": 7.675049,
    "lng": 5.07586
  },
  {
    "code": "EKS/EM/0298",
    "name": "Emure Ward 1 Market Square",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.467852,
    "lng": 5.46871
  },
  {
    "code": "EKS/EM/0299",
    "name": "Emure Ward 1 Primary School",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.446783,
    "lng": 5.44486
  },
  {
    "code": "EKS/EM/0300",
    "name": "Emure Ward 1 Post Office",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.43418,
    "lng": 5.427457
  },
  {
    "code": "EKS/EM/0301",
    "name": "Emure Ward 1 Town Hall",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.463034,
    "lng": 5.456916
  },
  {
    "code": "EKS/EM/0302",
    "name": "Emure Ward 1 Court Premises",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.441817,
    "lng": 5.432318
  },
  {
    "code": "EKS/EM/0303",
    "name": "Emure Ward 1 Youth Centre",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.447328,
    "lng": 5.46071
  },
  {
    "code": "EKS/EM/0304",
    "name": "Emure Ward 1 Church Hall",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.423239,
    "lng": 5.4586
  },
  {
    "code": "EKS/EM/0305",
    "name": "Emure Ward 1 Health Centre",
    "ward": "Emure Ward 1",
    "lga": "Emure",
    "lat": 7.409498,
    "lng": 5.464101
  },
  {
    "code": "EKS/EM/0306",
    "name": "Emure Ward 2 Court Premises",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.463749,
    "lng": 5.460659
  },
  {
    "code": "EKS/EM/0307",
    "name": "Emure Ward 2 Secondary School",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.400921,
    "lng": 5.425585
  },
  {
    "code": "EKS/EM/0308",
    "name": "Emure Ward 2 Court Premises",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.4532,
    "lng": 5.453195
  },
  {
    "code": "EKS/EM/0309",
    "name": "Emure Ward 2 Primary School",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.453017,
    "lng": 5.441374
  },
  {
    "code": "EKS/EM/0310",
    "name": "Emure Ward 2 Open Field",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.412627,
    "lng": 5.443884
  },
  {
    "code": "EKS/EM/0311",
    "name": "Emure Ward 2 Post Office",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.436394,
    "lng": 5.472795
  },
  {
    "code": "EKS/EM/0312",
    "name": "Emure Ward 2 Palace Premises",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.401888,
    "lng": 5.463086
  },
  {
    "code": "EKS/EM/0313",
    "name": "Emure Ward 2 Health Centre",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.416595,
    "lng": 5.48103
  },
  {
    "code": "EKS/EM/0314",
    "name": "Emure Ward 2 Market Square",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.426428,
    "lng": 5.445742
  },
  {
    "code": "EKS/EM/0315",
    "name": "Emure Ward 2 Health Centre",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.468462,
    "lng": 5.439104
  },
  {
    "code": "EKS/EM/0316",
    "name": "Emure Ward 2 Primary School",
    "ward": "Emure Ward 2",
    "lga": "Emure",
    "lat": 7.408685,
    "lng": 5.482044
  },
  {
    "code": "EKS/EM/0317",
    "name": "Iluomoba Secondary School",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.449576,
    "lng": 5.476418
  },
  {
    "code": "EKS/EM/0318",
    "name": "Iluomoba Secondary School",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.420498,
    "lng": 5.499073
  },
  {
    "code": "EKS/EM/0319",
    "name": "Iluomoba Church Hall",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.45566,
    "lng": 5.498465
  },
  {
    "code": "EKS/EM/0320",
    "name": "Iluomoba Open Field",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.467186,
    "lng": 5.4301
  },
  {
    "code": "EKS/EM/0321",
    "name": "Iluomoba Post Office",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.41656,
    "lng": 5.428029
  },
  {
    "code": "EKS/EM/0322",
    "name": "Iluomoba Church Hall",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.425224,
    "lng": 5.462076
  },
  {
    "code": "EKS/EM/0323",
    "name": "Iluomoba Post Office",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.391228,
    "lng": 5.431532
  },
  {
    "code": "EKS/EM/0324",
    "name": "Iluomoba Church Hall",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.442383,
    "lng": 5.432349
  },
  {
    "code": "EKS/EM/0325",
    "name": "Iluomoba Open Field",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.452522,
    "lng": 5.441202
  },
  {
    "code": "EKS/EM/0326",
    "name": "Iluomoba Post Office",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.445416,
    "lng": 5.471987
  },
  {
    "code": "EKS/EM/0327",
    "name": "Iluomoba Motor Park",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.416285,
    "lng": 5.473949
  },
  {
    "code": "EKS/EM/0328",
    "name": "Iluomoba Ward Office",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.420401,
    "lng": 5.445333
  },
  {
    "code": "EKS/EM/0329",
    "name": "Iluomoba Motor Park",
    "ward": "Iluomoba",
    "lga": "Emure",
    "lat": 7.460995,
    "lng": 5.459036
  },
  {
    "code": "EKS/EM/0330",
    "name": "Oke-Ayede Council Hall",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.439397,
    "lng": 5.438782
  },
  {
    "code": "EKS/EM/0331",
    "name": "Oke-Ayede Ward Office",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.463674,
    "lng": 5.499794
  },
  {
    "code": "EKS/EM/0332",
    "name": "Oke-Ayede Secondary School",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.39723,
    "lng": 5.498267
  },
  {
    "code": "EKS/EM/0333",
    "name": "Oke-Ayede Church Hall",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.4407,
    "lng": 5.489806
  },
  {
    "code": "EKS/EM/0334",
    "name": "Oke-Ayede Primary School",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.403309,
    "lng": 5.443957
  },
  {
    "code": "EKS/EM/0335",
    "name": "Oke-Ayede Youth Centre",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.393679,
    "lng": 5.483691
  },
  {
    "code": "EKS/EM/0336",
    "name": "Oke-Ayede Market Square",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.418677,
    "lng": 5.454455
  },
  {
    "code": "EKS/EM/0337",
    "name": "Oke-Ayede Secondary School",
    "ward": "Oke-Ayede",
    "lga": "Emure",
    "lat": 7.432493,
    "lng": 5.465274
  },
  {
    "code": "EKS/GB/0338",
    "name": "Ode-Ekiti Post Office",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.662599,
    "lng": 5.488317
  },
  {
    "code": "EKS/GB/0339",
    "name": "Ode-Ekiti Church Hall",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.679604,
    "lng": 5.536651
  },
  {
    "code": "EKS/GB/0340",
    "name": "Ode-Ekiti Church Hall",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.722026,
    "lng": 5.493449
  },
  {
    "code": "EKS/GB/0341",
    "name": "Ode-Ekiti Council Hall",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.700032,
    "lng": 5.518766
  },
  {
    "code": "EKS/GB/0342",
    "name": "Ode-Ekiti Court Premises",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.649752,
    "lng": 5.546371
  },
  {
    "code": "EKS/GB/0343",
    "name": "Ode-Ekiti Town Hall",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.672011,
    "lng": 5.525728
  },
  {
    "code": "EKS/GB/0344",
    "name": "Ode-Ekiti Open Field",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.684338,
    "lng": 5.509645
  },
  {
    "code": "EKS/GB/0345",
    "name": "Ode-Ekiti Ward Office",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.672932,
    "lng": 5.558962
  },
  {
    "code": "EKS/GB/0346",
    "name": "Ode-Ekiti Market Square",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.669008,
    "lng": 5.549624
  },
  {
    "code": "EKS/GB/0347",
    "name": "Ode-Ekiti Town Hall",
    "ward": "Ode-Ekiti",
    "lga": "Gbonyin",
    "lat": 7.72895,
    "lng": 5.550267
  },
  {
    "code": "EKS/GB/0348",
    "name": "Awo Youth Centre",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.679509,
    "lng": 5.510717
  },
  {
    "code": "EKS/GB/0349",
    "name": "Awo Post Office",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.728415,
    "lng": 5.505618
  },
  {
    "code": "EKS/GB/0350",
    "name": "Awo Open Field",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.701658,
    "lng": 5.503958
  },
  {
    "code": "EKS/GB/0351",
    "name": "Awo Primary School",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.718205,
    "lng": 5.544265
  },
  {
    "code": "EKS/GB/0352",
    "name": "Awo Post Office",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.721849,
    "lng": 5.541614
  },
  {
    "code": "EKS/GB/0353",
    "name": "Awo Secondary School",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.721332,
    "lng": 5.504896
  },
  {
    "code": "EKS/GB/0354",
    "name": "Awo Market Square",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.667409,
    "lng": 5.546155
  },
  {
    "code": "EKS/GB/0355",
    "name": "Awo Council Hall",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.699929,
    "lng": 5.531671
  },
  {
    "code": "EKS/GB/0356",
    "name": "Awo Council Hall",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.709446,
    "lng": 5.543398
  },
  {
    "code": "EKS/GB/0357",
    "name": "Awo Court Premises",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.716067,
    "lng": 5.53226
  },
  {
    "code": "EKS/GB/0358",
    "name": "Awo Secondary School",
    "ward": "Awo",
    "lga": "Gbonyin",
    "lat": 7.699197,
    "lng": 5.485154
  },
  {
    "code": "EKS/GB/0359",
    "name": "Ilupeju Community Centre",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.651669,
    "lng": 5.511189
  },
  {
    "code": "EKS/GB/0360",
    "name": "Ilupeju Ward Office",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.656211,
    "lng": 5.505609
  },
  {
    "code": "EKS/GB/0361",
    "name": "Ilupeju Secondary School",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.68224,
    "lng": 5.498064
  },
  {
    "code": "EKS/GB/0362",
    "name": "Ilupeju Motor Park",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.692153,
    "lng": 5.559719
  },
  {
    "code": "EKS/GB/0363",
    "name": "Ilupeju Community Centre",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.689144,
    "lng": 5.503802
  },
  {
    "code": "EKS/GB/0364",
    "name": "Ilupeju Church Hall",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.669558,
    "lng": 5.547975
  },
  {
    "code": "EKS/GB/0365",
    "name": "Ilupeju Post Office",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.726391,
    "lng": 5.505611
  },
  {
    "code": "EKS/GB/0366",
    "name": "Ilupeju Town Hall",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.676097,
    "lng": 5.491214
  },
  {
    "code": "EKS/GB/0367",
    "name": "Ilupeju Post Office",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.660261,
    "lng": 5.55932
  },
  {
    "code": "EKS/GB/0368",
    "name": "Ilupeju Health Centre",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.703106,
    "lng": 5.535952
  },
  {
    "code": "EKS/GB/0369",
    "name": "Ilupeju Palace Premises",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.726382,
    "lng": 5.546367
  },
  {
    "code": "EKS/GB/0370",
    "name": "Ilupeju Youth Centre",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.656224,
    "lng": 5.513566
  },
  {
    "code": "EKS/GB/0371",
    "name": "Ilupeju Council Hall",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.691926,
    "lng": 5.518383
  },
  {
    "code": "EKS/GB/0372",
    "name": "Ilupeju Health Centre",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.708921,
    "lng": 5.502973
  },
  {
    "code": "EKS/GB/0373",
    "name": "Ilupeju Town Hall",
    "ward": "Ilupeju",
    "lga": "Gbonyin",
    "lat": 7.714793,
    "lng": 5.557223
  },
  {
    "code": "EKS/GB/0374",
    "name": "Ikun Court Premises",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.667706,
    "lng": 5.484002
  },
  {
    "code": "EKS/GB/0375",
    "name": "Ikun Open Field",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.724454,
    "lng": 5.508241
  },
  {
    "code": "EKS/GB/0376",
    "name": "Ikun Post Office",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.666709,
    "lng": 5.487057
  },
  {
    "code": "EKS/GB/0377",
    "name": "Ikun Council Hall",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.686141,
    "lng": 5.538086
  },
  {
    "code": "EKS/GB/0378",
    "name": "Ikun Primary School",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.681664,
    "lng": 5.493182
  },
  {
    "code": "EKS/GB/0379",
    "name": "Ikun Town Hall",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.673349,
    "lng": 5.52141
  },
  {
    "code": "EKS/GB/0380",
    "name": "Ikun Health Centre",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.667784,
    "lng": 5.525004
  },
  {
    "code": "EKS/GB/0381",
    "name": "Ikun Ward Office",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.685292,
    "lng": 5.535639
  },
  {
    "code": "EKS/GB/0382",
    "name": "Ikun Open Field",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.704719,
    "lng": 5.525215
  },
  {
    "code": "EKS/GB/0383",
    "name": "Ikun Health Centre",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.708382,
    "lng": 5.494362
  },
  {
    "code": "EKS/GB/0384",
    "name": "Ikun Open Field",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.701394,
    "lng": 5.548695
  },
  {
    "code": "EKS/GB/0385",
    "name": "Ikun Primary School",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.681649,
    "lng": 5.558122
  },
  {
    "code": "EKS/GB/0386",
    "name": "Ikun Church Hall",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.704222,
    "lng": 5.499382
  },
  {
    "code": "EKS/GB/0387",
    "name": "Ikun Town Hall",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.725044,
    "lng": 5.550436
  },
  {
    "code": "EKS/GB/0388",
    "name": "Ikun Court Premises",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.727474,
    "lng": 5.511387
  },
  {
    "code": "EKS/GB/0389",
    "name": "Ikun Health Centre",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.727227,
    "lng": 5.510694
  },
  {
    "code": "EKS/GB/0390",
    "name": "Ikun Post Office",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.671071,
    "lng": 5.559457
  },
  {
    "code": "EKS/GB/0391",
    "name": "Ikun Market Square",
    "ward": "Ikun",
    "lga": "Gbonyin",
    "lat": 7.714935,
    "lng": 5.489334
  },
  {
    "code": "EKS/IO/0392",
    "name": "Ido Ward 1 Primary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.851159,
    "lng": 5.217687
  },
  {
    "code": "EKS/IO/0393",
    "name": "Ido Ward 1 Community Centre",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.862944,
    "lng": 5.159486
  },
  {
    "code": "EKS/IO/0394",
    "name": "Ido Ward 1 Post Office",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.862958,
    "lng": 5.156416
  },
  {
    "code": "EKS/IO/0395",
    "name": "Ido Ward 1 Market Square",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.861213,
    "lng": 5.156573
  },
  {
    "code": "EKS/IO/0396",
    "name": "Ido Ward 1 Secondary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.865044,
    "lng": 5.15864
  },
  {
    "code": "EKS/IO/0397",
    "name": "Ido Ward 1 Primary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.811804,
    "lng": 5.212042
  },
  {
    "code": "EKS/IO/0398",
    "name": "Ido Ward 1 Community Centre",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.822182,
    "lng": 5.218722
  },
  {
    "code": "EKS/IO/0399",
    "name": "Ido Ward 1 Town Hall",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.843217,
    "lng": 5.203881
  },
  {
    "code": "EKS/IO/0400",
    "name": "Ido Ward 1 Primary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.852885,
    "lng": 5.142062
  },
  {
    "code": "EKS/IO/0401",
    "name": "Ido Ward 1 Open Field",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.828659,
    "lng": 5.203075
  },
  {
    "code": "EKS/IO/0402",
    "name": "Ido Ward 1 Primary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.825902,
    "lng": 5.15394
  },
  {
    "code": "EKS/IO/0403",
    "name": "Ido Ward 1 Town Hall",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.810141,
    "lng": 5.173677
  },
  {
    "code": "EKS/IO/0404",
    "name": "Ido Ward 1 Secondary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.859653,
    "lng": 5.1781
  },
  {
    "code": "EKS/IO/0405",
    "name": "Ido Ward 1 Church Hall",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.828963,
    "lng": 5.187493
  },
  {
    "code": "EKS/IO/0406",
    "name": "Ido Ward 1 Primary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.840307,
    "lng": 5.215633
  },
  {
    "code": "EKS/IO/0407",
    "name": "Ido Ward 1 Council Hall",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.858179,
    "lng": 5.2127
  },
  {
    "code": "EKS/IO/0408",
    "name": "Ido Ward 1 Primary School",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.841716,
    "lng": 5.176643
  },
  {
    "code": "EKS/IO/0409",
    "name": "Ido Ward 1 Health Centre",
    "ward": "Ido Ward 1",
    "lga": "Ido Osi",
    "lat": 7.804866,
    "lng": 5.178319
  },
  {
    "code": "EKS/IO/0410",
    "name": "Ido Ward 2 Court Premises",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.854888,
    "lng": 5.179222
  },
  {
    "code": "EKS/IO/0411",
    "name": "Ido Ward 2 Palace Premises",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.835485,
    "lng": 5.211941
  },
  {
    "code": "EKS/IO/0412",
    "name": "Ido Ward 2 Youth Centre",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.848664,
    "lng": 5.145255
  },
  {
    "code": "EKS/IO/0413",
    "name": "Ido Ward 2 Ward Office",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.849945,
    "lng": 5.186829
  },
  {
    "code": "EKS/IO/0414",
    "name": "Ido Ward 2 Motor Park",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.826015,
    "lng": 5.21957
  },
  {
    "code": "EKS/IO/0415",
    "name": "Ido Ward 2 Health Centre",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.823592,
    "lng": 5.180444
  },
  {
    "code": "EKS/IO/0416",
    "name": "Ido Ward 2 Post Office",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.807934,
    "lng": 5.196142
  },
  {
    "code": "EKS/IO/0417",
    "name": "Ido Ward 2 Motor Park",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.852377,
    "lng": 5.210216
  },
  {
    "code": "EKS/IO/0418",
    "name": "Ido Ward 2 Church Hall",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.857667,
    "lng": 5.157202
  },
  {
    "code": "EKS/IO/0419",
    "name": "Ido Ward 2 Post Office",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.871047,
    "lng": 5.173105
  },
  {
    "code": "EKS/IO/0420",
    "name": "Ido Ward 2 Town Hall",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.83628,
    "lng": 5.173279
  },
  {
    "code": "EKS/IO/0421",
    "name": "Ido Ward 2 Youth Centre",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.825004,
    "lng": 5.165002
  },
  {
    "code": "EKS/IO/0422",
    "name": "Ido Ward 2 Court Premises",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.829944,
    "lng": 5.152211
  },
  {
    "code": "EKS/IO/0423",
    "name": "Ido Ward 2 Town Hall",
    "ward": "Ido Ward 2",
    "lga": "Ido Osi",
    "lat": 7.837941,
    "lng": 5.147298
  },
  {
    "code": "EKS/IO/0424",
    "name": "Osi Ward Palace Premises",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.83455,
    "lng": 5.199567
  },
  {
    "code": "EKS/IO/0425",
    "name": "Osi Ward Open Field",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.864942,
    "lng": 5.18451
  },
  {
    "code": "EKS/IO/0426",
    "name": "Osi Ward Council Hall",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.87653,
    "lng": 5.184935
  },
  {
    "code": "EKS/IO/0427",
    "name": "Osi Ward Council Hall",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.809779,
    "lng": 5.168288
  },
  {
    "code": "EKS/IO/0428",
    "name": "Osi Ward Court Premises",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.87529,
    "lng": 5.173835
  },
  {
    "code": "EKS/IO/0429",
    "name": "Osi Ward Open Field",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.857685,
    "lng": 5.217472
  },
  {
    "code": "EKS/IO/0430",
    "name": "Osi Ward Motor Park",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.824996,
    "lng": 5.148288
  },
  {
    "code": "EKS/IO/0431",
    "name": "Osi Ward Market Square",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.817019,
    "lng": 5.192539
  },
  {
    "code": "EKS/IO/0432",
    "name": "Osi Ward Motor Park",
    "ward": "Osi Ward",
    "lga": "Ido Osi",
    "lat": 7.867782,
    "lng": 5.168009
  },
  {
    "code": "EKS/IO/0433",
    "name": "Epe Ward Market Square",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.809191,
    "lng": 5.162285
  },
  {
    "code": "EKS/IO/0434",
    "name": "Epe Ward Secondary School",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.864578,
    "lng": 5.207612
  },
  {
    "code": "EKS/IO/0435",
    "name": "Epe Ward Council Hall",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.865474,
    "lng": 5.189086
  },
  {
    "code": "EKS/IO/0436",
    "name": "Epe Ward Council Hall",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.844539,
    "lng": 5.18872
  },
  {
    "code": "EKS/IO/0437",
    "name": "Epe Ward Community Centre",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.866357,
    "lng": 5.161396
  },
  {
    "code": "EKS/IO/0438",
    "name": "Epe Ward Court Premises",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.821862,
    "lng": 5.200993
  },
  {
    "code": "EKS/IO/0439",
    "name": "Epe Ward Post Office",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.827186,
    "lng": 5.140488
  },
  {
    "code": "EKS/IO/0440",
    "name": "Epe Ward Town Hall",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.81146,
    "lng": 5.192588
  },
  {
    "code": "EKS/IO/0441",
    "name": "Epe Ward Primary School",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.81135,
    "lng": 5.190654
  },
  {
    "code": "EKS/IO/0442",
    "name": "Epe Ward Health Centre",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.807341,
    "lng": 5.182439
  },
  {
    "code": "EKS/IO/0443",
    "name": "Epe Ward Palace Premises",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.833587,
    "lng": 5.167272
  },
  {
    "code": "EKS/IO/0444",
    "name": "Epe Ward Open Field",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.824931,
    "lng": 5.165951
  },
  {
    "code": "EKS/IO/0445",
    "name": "Epe Ward Community Centre",
    "ward": "Epe Ward",
    "lga": "Ido Osi",
    "lat": 7.847698,
    "lng": 5.210667
  },
  {
    "code": "EKS/IJ/0446",
    "name": "Ijero Ward 1 Town Hall",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.832355,
    "lng": 5.033981
  },
  {
    "code": "EKS/IJ/0447",
    "name": "Ijero Ward 1 Church Hall",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.793768,
    "lng": 5.082955
  },
  {
    "code": "EKS/IJ/0448",
    "name": "Ijero Ward 1 Market Square",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.820566,
    "lng": 5.063135
  },
  {
    "code": "EKS/IJ/0449",
    "name": "Ijero Ward 1 Health Centre",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.832395,
    "lng": 5.039105
  },
  {
    "code": "EKS/IJ/0450",
    "name": "Ijero Ward 1 Open Field",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.780871,
    "lng": 5.084257
  },
  {
    "code": "EKS/IJ/0451",
    "name": "Ijero Ward 1 Primary School",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.810931,
    "lng": 5.083371
  },
  {
    "code": "EKS/IJ/0452",
    "name": "Ijero Ward 1 Primary School",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.789641,
    "lng": 5.108756
  },
  {
    "code": "EKS/IJ/0453",
    "name": "Ijero Ward 1 Market Square",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.772615,
    "lng": 5.054114
  },
  {
    "code": "EKS/IJ/0454",
    "name": "Ijero Ward 1 Youth Centre",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.833388,
    "lng": 5.091133
  },
  {
    "code": "EKS/IJ/0455",
    "name": "Ijero Ward 1 Ward Office",
    "ward": "Ijero Ward 1",
    "lga": "Ijero",
    "lat": 7.79825,
    "lng": 5.030618
  },
  {
    "code": "EKS/IJ/0456",
    "name": "Ijero Ward 2 Ward Office",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.786056,
    "lng": 5.060417
  },
  {
    "code": "EKS/IJ/0457",
    "name": "Ijero Ward 2 Council Hall",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.790409,
    "lng": 5.074698
  },
  {
    "code": "EKS/IJ/0458",
    "name": "Ijero Ward 2 Post Office",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.836496,
    "lng": 5.035766
  },
  {
    "code": "EKS/IJ/0459",
    "name": "Ijero Ward 2 Church Hall",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.831363,
    "lng": 5.064898
  },
  {
    "code": "EKS/IJ/0460",
    "name": "Ijero Ward 2 Open Field",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.845693,
    "lng": 5.098969
  },
  {
    "code": "EKS/IJ/0461",
    "name": "Ijero Ward 2 Council Hall",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.806343,
    "lng": 5.062354
  },
  {
    "code": "EKS/IJ/0462",
    "name": "Ijero Ward 2 Primary School",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.805416,
    "lng": 5.039214
  },
  {
    "code": "EKS/IJ/0463",
    "name": "Ijero Ward 2 Open Field",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.849296,
    "lng": 5.04375
  },
  {
    "code": "EKS/IJ/0464",
    "name": "Ijero Ward 2 Palace Premises",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.808808,
    "lng": 5.085169
  },
  {
    "code": "EKS/IJ/0465",
    "name": "Ijero Ward 2 Market Square",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.77905,
    "lng": 5.097559
  },
  {
    "code": "EKS/IJ/0466",
    "name": "Ijero Ward 2 Town Hall",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.806854,
    "lng": 5.062036
  },
  {
    "code": "EKS/IJ/0467",
    "name": "Ijero Ward 2 Palace Premises",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.803661,
    "lng": 5.054822
  },
  {
    "code": "EKS/IJ/0468",
    "name": "Ijero Ward 2 Town Hall",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.789726,
    "lng": 5.092329
  },
  {
    "code": "EKS/IJ/0469",
    "name": "Ijero Ward 2 Motor Park",
    "ward": "Ijero Ward 2",
    "lga": "Ijero",
    "lat": 7.812839,
    "lng": 5.039122
  },
  {
    "code": "EKS/IJ/0470",
    "name": "Iye-Ekiti Ward Office",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.844474,
    "lng": 5.05795
  },
  {
    "code": "EKS/IJ/0471",
    "name": "Iye-Ekiti Community Centre",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.848658,
    "lng": 5.081635
  },
  {
    "code": "EKS/IJ/0472",
    "name": "Iye-Ekiti Market Square",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.790902,
    "lng": 5.041716
  },
  {
    "code": "EKS/IJ/0473",
    "name": "Iye-Ekiti Secondary School",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.78588,
    "lng": 5.04223
  },
  {
    "code": "EKS/IJ/0474",
    "name": "Iye-Ekiti Secondary School",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.824441,
    "lng": 5.044172
  },
  {
    "code": "EKS/IJ/0475",
    "name": "Iye-Ekiti Open Field",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.822236,
    "lng": 5.067116
  },
  {
    "code": "EKS/IJ/0476",
    "name": "Iye-Ekiti Court Premises",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.83279,
    "lng": 5.065912
  },
  {
    "code": "EKS/IJ/0477",
    "name": "Iye-Ekiti Open Field",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.842564,
    "lng": 5.081439
  },
  {
    "code": "EKS/IJ/0478",
    "name": "Iye-Ekiti Palace Premises",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.797857,
    "lng": 5.107678
  },
  {
    "code": "EKS/IJ/0479",
    "name": "Iye-Ekiti Church Hall",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.784077,
    "lng": 5.035463
  },
  {
    "code": "EKS/IJ/0480",
    "name": "Iye-Ekiti Open Field",
    "ward": "Iye-Ekiti",
    "lga": "Ijero",
    "lat": 7.822511,
    "lng": 5.093706
  },
  {
    "code": "EKS/IJ/0481",
    "name": "Ilogbo Church Hall",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.800155,
    "lng": 5.035935
  },
  {
    "code": "EKS/IJ/0482",
    "name": "Ilogbo Post Office",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.808153,
    "lng": 5.034551
  },
  {
    "code": "EKS/IJ/0483",
    "name": "Ilogbo Post Office",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.794966,
    "lng": 5.081573
  },
  {
    "code": "EKS/IJ/0484",
    "name": "Ilogbo Health Centre",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.779224,
    "lng": 5.077526
  },
  {
    "code": "EKS/IJ/0485",
    "name": "Ilogbo Secondary School",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.809017,
    "lng": 5.074345
  },
  {
    "code": "EKS/IJ/0486",
    "name": "Ilogbo Court Premises",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.831114,
    "lng": 5.033282
  },
  {
    "code": "EKS/IJ/0487",
    "name": "Ilogbo Palace Premises",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.836785,
    "lng": 5.082147
  },
  {
    "code": "EKS/IJ/0488",
    "name": "Ilogbo Primary School",
    "ward": "Ilogbo",
    "lga": "Ijero",
    "lat": 7.8204,
    "lng": 5.070109
  },
  {
    "code": "EKS/IJ/0489",
    "name": "Ishan Palace Premises",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.78028,
    "lng": 5.10193
  },
  {
    "code": "EKS/IJ/0490",
    "name": "Ishan Council Hall",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.850591,
    "lng": 5.036746
  },
  {
    "code": "EKS/IJ/0491",
    "name": "Ishan Church Hall",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.785805,
    "lng": 5.049819
  },
  {
    "code": "EKS/IJ/0492",
    "name": "Ishan Open Field",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.851279,
    "lng": 5.071925
  },
  {
    "code": "EKS/IJ/0493",
    "name": "Ishan Youth Centre",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.7847,
    "lng": 5.059828
  },
  {
    "code": "EKS/IJ/0494",
    "name": "Ishan Council Hall",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.802993,
    "lng": 5.091957
  },
  {
    "code": "EKS/IJ/0495",
    "name": "Ishan Council Hall",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.819831,
    "lng": 5.093138
  },
  {
    "code": "EKS/IJ/0496",
    "name": "Ishan Motor Park",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.798772,
    "lng": 5.056375
  },
  {
    "code": "EKS/IJ/0497",
    "name": "Ishan Ward Office",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.82627,
    "lng": 5.052732
  },
  {
    "code": "EKS/IJ/0498",
    "name": "Ishan Open Field",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.840125,
    "lng": 5.107153
  },
  {
    "code": "EKS/IJ/0499",
    "name": "Ishan Open Field",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.841862,
    "lng": 5.056669
  },
  {
    "code": "EKS/IJ/0500",
    "name": "Ishan Youth Centre",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.825089,
    "lng": 5.10334
  },
  {
    "code": "EKS/IJ/0501",
    "name": "Ishan Health Centre",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.849416,
    "lng": 5.085878
  },
  {
    "code": "EKS/IJ/0502",
    "name": "Ishan Town Hall",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.782316,
    "lng": 5.086707
  },
  {
    "code": "EKS/IJ/0503",
    "name": "Ishan Secondary School",
    "ward": "Ishan",
    "lga": "Ijero",
    "lat": 7.796767,
    "lng": 5.060134
  },
  {
    "code": "EKS/IK/0504",
    "name": "Ikere Ward 1 Post Office",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.539055,
    "lng": 5.252509
  },
  {
    "code": "EKS/IK/0505",
    "name": "Ikere Ward 1 Court Premises",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.549769,
    "lng": 5.278673
  },
  {
    "code": "EKS/IK/0506",
    "name": "Ikere Ward 1 Health Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.516111,
    "lng": 5.250582
  },
  {
    "code": "EKS/IK/0507",
    "name": "Ikere Ward 1 Youth Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.514679,
    "lng": 5.200358
  },
  {
    "code": "EKS/IK/0508",
    "name": "Ikere Ward 1 Secondary School",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.488421,
    "lng": 5.216035
  },
  {
    "code": "EKS/IK/0509",
    "name": "Ikere Ward 1 Community Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.512902,
    "lng": 5.217023
  },
  {
    "code": "EKS/IK/0510",
    "name": "Ikere Ward 1 Secondary School",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.486396,
    "lng": 5.222563
  },
  {
    "code": "EKS/IK/0511",
    "name": "Ikere Ward 1 Post Office",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.482091,
    "lng": 5.26057
  },
  {
    "code": "EKS/IK/0512",
    "name": "Ikere Ward 1 Council Hall",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.533092,
    "lng": 5.241023
  },
  {
    "code": "EKS/IK/0513",
    "name": "Ikere Ward 1 Community Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.500941,
    "lng": 5.260205
  },
  {
    "code": "EKS/IK/0514",
    "name": "Ikere Ward 1 Community Centre",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.52178,
    "lng": 5.21124
  },
  {
    "code": "EKS/IK/0515",
    "name": "Ikere Ward 1 Secondary School",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.540508,
    "lng": 5.260588
  },
  {
    "code": "EKS/IK/0516",
    "name": "Ikere Ward 1 Primary School",
    "ward": "Ikere Ward 1",
    "lga": "Ikere",
    "lat": 7.546212,
    "lng": 5.256595
  },
  {
    "code": "EKS/IK/0517",
    "name": "Ikere Ward 2 Church Hall",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.503144,
    "lng": 5.256467
  },
  {
    "code": "EKS/IK/0518",
    "name": "Ikere Ward 2 Secondary School",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.522848,
    "lng": 5.259091
  },
  {
    "code": "EKS/IK/0519",
    "name": "Ikere Ward 2 Youth Centre",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.509914,
    "lng": 5.241621
  },
  {
    "code": "EKS/IK/0520",
    "name": "Ikere Ward 2 Court Premises",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.551248,
    "lng": 5.26165
  },
  {
    "code": "EKS/IK/0521",
    "name": "Ikere Ward 2 Open Field",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.540809,
    "lng": 5.228327
  },
  {
    "code": "EKS/IK/0522",
    "name": "Ikere Ward 2 Youth Centre",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.552755,
    "lng": 5.235834
  },
  {
    "code": "EKS/IK/0523",
    "name": "Ikere Ward 2 Health Centre",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.53625,
    "lng": 5.239133
  },
  {
    "code": "EKS/IK/0524",
    "name": "Ikere Ward 2 Secondary School",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.551301,
    "lng": 5.264251
  },
  {
    "code": "EKS/IK/0525",
    "name": "Ikere Ward 2 Primary School",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.522373,
    "lng": 5.26874
  },
  {
    "code": "EKS/IK/0526",
    "name": "Ikere Ward 2 Motor Park",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.525294,
    "lng": 5.268829
  },
  {
    "code": "EKS/IK/0527",
    "name": "Ikere Ward 2 Motor Park",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.548743,
    "lng": 5.255812
  },
  {
    "code": "EKS/IK/0528",
    "name": "Ikere Ward 2 Secondary School",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.542093,
    "lng": 5.221705
  },
  {
    "code": "EKS/IK/0529",
    "name": "Ikere Ward 2 Motor Park",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.486825,
    "lng": 5.234846
  },
  {
    "code": "EKS/IK/0530",
    "name": "Ikere Ward 2 Court Premises",
    "ward": "Ikere Ward 2",
    "lga": "Ikere",
    "lat": 7.485788,
    "lng": 5.233898
  },
  {
    "code": "EKS/IK/0531",
    "name": "Ikere Ward 3 Court Premises",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.539336,
    "lng": 5.26967
  },
  {
    "code": "EKS/IK/0532",
    "name": "Ikere Ward 3 Motor Park",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.476134,
    "lng": 5.203161
  },
  {
    "code": "EKS/IK/0533",
    "name": "Ikere Ward 3 Town Hall",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.503917,
    "lng": 5.229793
  },
  {
    "code": "EKS/IK/0534",
    "name": "Ikere Ward 3 Court Premises",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.503993,
    "lng": 5.201155
  },
  {
    "code": "EKS/IK/0535",
    "name": "Ikere Ward 3 Palace Premises",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.481927,
    "lng": 5.256076
  },
  {
    "code": "EKS/IK/0536",
    "name": "Ikere Ward 3 Youth Centre",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.53731,
    "lng": 5.209908
  },
  {
    "code": "EKS/IK/0537",
    "name": "Ikere Ward 3 Post Office",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.547392,
    "lng": 5.236696
  },
  {
    "code": "EKS/IK/0538",
    "name": "Ikere Ward 3 Church Hall",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.485103,
    "lng": 5.255343
  },
  {
    "code": "EKS/IK/0539",
    "name": "Ikere Ward 3 Primary School",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.523228,
    "lng": 5.271369
  },
  {
    "code": "EKS/IK/0540",
    "name": "Ikere Ward 3 Motor Park",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.494474,
    "lng": 5.265697
  },
  {
    "code": "EKS/IK/0541",
    "name": "Ikere Ward 3 Health Centre",
    "ward": "Ikere Ward 3",
    "lga": "Ikere",
    "lat": 7.549218,
    "lng": 5.24761
  },
  {
    "code": "EKS/IK/0542",
    "name": "Ikere Ward 4 Town Hall",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.536094,
    "lng": 5.217911
  },
  {
    "code": "EKS/IK/0543",
    "name": "Ikere Ward 4 Secondary School",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.47782,
    "lng": 5.232486
  },
  {
    "code": "EKS/IK/0544",
    "name": "Ikere Ward 4 Post Office",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.523825,
    "lng": 5.203925
  },
  {
    "code": "EKS/IK/0545",
    "name": "Ikere Ward 4 Primary School",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.546412,
    "lng": 5.246639
  },
  {
    "code": "EKS/IK/0546",
    "name": "Ikere Ward 4 Ward Office",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.524556,
    "lng": 5.244904
  },
  {
    "code": "EKS/IK/0547",
    "name": "Ikere Ward 4 Open Field",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.485486,
    "lng": 5.233239
  },
  {
    "code": "EKS/IK/0548",
    "name": "Ikere Ward 4 Community Centre",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.502225,
    "lng": 5.244553
  },
  {
    "code": "EKS/IK/0549",
    "name": "Ikere Ward 4 Palace Premises",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.52715,
    "lng": 5.205749
  },
  {
    "code": "EKS/IK/0550",
    "name": "Ikere Ward 4 Motor Park",
    "ward": "Ikere Ward 4",
    "lga": "Ikere",
    "lat": 7.479414,
    "lng": 5.240985
  },
  {
    "code": "EKS/IK/0551",
    "name": "Agbado Church Hall",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.518332,
    "lng": 5.230136
  },
  {
    "code": "EKS/IK/0552",
    "name": "Agbado Palace Premises",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.477483,
    "lng": 5.229851
  },
  {
    "code": "EKS/IK/0553",
    "name": "Agbado Secondary School",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.494292,
    "lng": 5.200199
  },
  {
    "code": "EKS/IK/0554",
    "name": "Agbado Council Hall",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.479405,
    "lng": 5.21819
  },
  {
    "code": "EKS/IK/0555",
    "name": "Agbado Ward Office",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.524261,
    "lng": 5.26062
  },
  {
    "code": "EKS/IK/0556",
    "name": "Agbado Palace Premises",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.534534,
    "lng": 5.209573
  },
  {
    "code": "EKS/IK/0557",
    "name": "Agbado Community Centre",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.517681,
    "lng": 5.263981
  },
  {
    "code": "EKS/IK/0558",
    "name": "Agbado Ward Office",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.540431,
    "lng": 5.253675
  },
  {
    "code": "EKS/IK/0559",
    "name": "Agbado Community Centre",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.512282,
    "lng": 5.213482
  },
  {
    "code": "EKS/IK/0560",
    "name": "Agbado Church Hall",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.479048,
    "lng": 5.260995
  },
  {
    "code": "EKS/IK/0561",
    "name": "Agbado Secondary School",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.476959,
    "lng": 5.215027
  },
  {
    "code": "EKS/IK/0562",
    "name": "Agbado Court Premises",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.489958,
    "lng": 5.202252
  },
  {
    "code": "EKS/IK/0563",
    "name": "Agbado Post Office",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.498806,
    "lng": 5.230758
  },
  {
    "code": "EKS/IK/0564",
    "name": "Agbado Secondary School",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.517442,
    "lng": 5.219165
  },
  {
    "code": "EKS/IK/0565",
    "name": "Agbado Post Office",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.525752,
    "lng": 5.221789
  },
  {
    "code": "EKS/IK/0566",
    "name": "Agbado Palace Premises",
    "ward": "Agbado",
    "lga": "Ikere",
    "lat": 7.536467,
    "lng": 5.268164
  },
  {
    "code": "EKS/IL/0567",
    "name": "Ikole Ward 1 Court Premises",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.749958,
    "lng": 5.489442
  },
  {
    "code": "EKS/IL/0568",
    "name": "Ikole Ward 1 Health Centre",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.772002,
    "lng": 5.495179
  },
  {
    "code": "EKS/IL/0569",
    "name": "Ikole Ward 1 Ward Office",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.767123,
    "lng": 5.474945
  },
  {
    "code": "EKS/IL/0570",
    "name": "Ikole Ward 1 Motor Park",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.779802,
    "lng": 5.533945
  },
  {
    "code": "EKS/IL/0571",
    "name": "Ikole Ward 1 Health Centre",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.761338,
    "lng": 5.466609
  },
  {
    "code": "EKS/IL/0572",
    "name": "Ikole Ward 1 Post Office",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.746314,
    "lng": 5.508196
  },
  {
    "code": "EKS/IL/0573",
    "name": "Ikole Ward 1 Town Hall",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.754437,
    "lng": 5.483501
  },
  {
    "code": "EKS/IL/0574",
    "name": "Ikole Ward 1 Youth Centre",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.746406,
    "lng": 5.512874
  },
  {
    "code": "EKS/IL/0575",
    "name": "Ikole Ward 1 Community Centre",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.775673,
    "lng": 5.517413
  },
  {
    "code": "EKS/IL/0576",
    "name": "Ikole Ward 1 Primary School",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.795181,
    "lng": 5.488124
  },
  {
    "code": "EKS/IL/0577",
    "name": "Ikole Ward 1 Open Field",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.798145,
    "lng": 5.532929
  },
  {
    "code": "EKS/IL/0578",
    "name": "Ikole Ward 1 Secondary School",
    "ward": "Ikole Ward 1",
    "lga": "Ikole",
    "lat": 7.819852,
    "lng": 5.481964
  },
  {
    "code": "EKS/IL/0579",
    "name": "Ikole Ward 2 Palace Premises",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.746003,
    "lng": 5.511001
  },
  {
    "code": "EKS/IL/0580",
    "name": "Ikole Ward 2 Community Centre",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.781047,
    "lng": 5.519992
  },
  {
    "code": "EKS/IL/0581",
    "name": "Ikole Ward 2 Open Field",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.816223,
    "lng": 5.471422
  },
  {
    "code": "EKS/IL/0582",
    "name": "Ikole Ward 2 Community Centre",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.794247,
    "lng": 5.495054
  },
  {
    "code": "EKS/IL/0583",
    "name": "Ikole Ward 2 Palace Premises",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.745379,
    "lng": 5.522281
  },
  {
    "code": "EKS/IL/0584",
    "name": "Ikole Ward 2 Primary School",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.768972,
    "lng": 5.535957
  },
  {
    "code": "EKS/IL/0585",
    "name": "Ikole Ward 2 Palace Premises",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.788408,
    "lng": 5.514325
  },
  {
    "code": "EKS/IL/0586",
    "name": "Ikole Ward 2 Open Field",
    "ward": "Ikole Ward 2",
    "lga": "Ikole",
    "lat": 7.769761,
    "lng": 5.521047
  },
  {
    "code": "EKS/IL/0587",
    "name": "Omuo-Ekiti Council Hall",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.782357,
    "lng": 5.491843
  },
  {
    "code": "EKS/IL/0588",
    "name": "Omuo-Ekiti Primary School",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.762295,
    "lng": 5.536842
  },
  {
    "code": "EKS/IL/0589",
    "name": "Omuo-Ekiti Health Centre",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.798854,
    "lng": 5.499924
  },
  {
    "code": "EKS/IL/0590",
    "name": "Omuo-Ekiti Secondary School",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.813083,
    "lng": 5.469421
  },
  {
    "code": "EKS/IL/0591",
    "name": "Omuo-Ekiti Open Field",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.760823,
    "lng": 5.495702
  },
  {
    "code": "EKS/IL/0592",
    "name": "Omuo-Ekiti Church Hall",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.762846,
    "lng": 5.533318
  },
  {
    "code": "EKS/IL/0593",
    "name": "Omuo-Ekiti Town Hall",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.756014,
    "lng": 5.470858
  },
  {
    "code": "EKS/IL/0594",
    "name": "Omuo-Ekiti Church Hall",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.776163,
    "lng": 5.531894
  },
  {
    "code": "EKS/IL/0595",
    "name": "Omuo-Ekiti Post Office",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.819781,
    "lng": 5.524841
  },
  {
    "code": "EKS/IL/0596",
    "name": "Omuo-Ekiti Ward Office",
    "ward": "Omuo-Ekiti",
    "lga": "Ikole",
    "lat": 7.818926,
    "lng": 5.513427
  },
  {
    "code": "EKS/IL/0597",
    "name": "Iyemero Youth Centre",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.784,
    "lng": 5.483229
  },
  {
    "code": "EKS/IL/0598",
    "name": "Iyemero Court Premises",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.808109,
    "lng": 5.516945
  },
  {
    "code": "EKS/IL/0599",
    "name": "Iyemero Palace Premises",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.796018,
    "lng": 5.473927
  },
  {
    "code": "EKS/IL/0600",
    "name": "Iyemero Market Square",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.7807,
    "lng": 5.469709
  },
  {
    "code": "EKS/IL/0601",
    "name": "Iyemero Church Hall",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.803365,
    "lng": 5.478939
  },
  {
    "code": "EKS/IL/0602",
    "name": "Iyemero Palace Premises",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.742103,
    "lng": 5.504322
  },
  {
    "code": "EKS/IL/0603",
    "name": "Iyemero Community Centre",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.777392,
    "lng": 5.538641
  },
  {
    "code": "EKS/IL/0604",
    "name": "Iyemero Youth Centre",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.788956,
    "lng": 5.466897
  },
  {
    "code": "EKS/IL/0605",
    "name": "Iyemero Church Hall",
    "ward": "Iyemero",
    "lga": "Ikole",
    "lat": 7.771853,
    "lng": 5.517355
  },
  {
    "code": "EKS/ILJ/0606",
    "name": "Iye-Ekiti Open Field",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.912864,
    "lng": 5.332755
  },
  {
    "code": "EKS/ILJ/0607",
    "name": "Iye-Ekiti Council Hall",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.8859,
    "lng": 5.37779
  },
  {
    "code": "EKS/ILJ/0608",
    "name": "Iye-Ekiti Motor Park",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.885933,
    "lng": 5.337267
  },
  {
    "code": "EKS/ILJ/0609",
    "name": "Iye-Ekiti Secondary School",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.907561,
    "lng": 5.370237
  },
  {
    "code": "EKS/ILJ/0610",
    "name": "Iye-Ekiti Secondary School",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.924104,
    "lng": 5.347023
  },
  {
    "code": "EKS/ILJ/0611",
    "name": "Iye-Ekiti Court Premises",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.957301,
    "lng": 5.334609
  },
  {
    "code": "EKS/ILJ/0612",
    "name": "Iye-Ekiti Motor Park",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.949457,
    "lng": 5.366511
  },
  {
    "code": "EKS/ILJ/0613",
    "name": "Iye-Ekiti Palace Premises",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.892241,
    "lng": 5.313173
  },
  {
    "code": "EKS/ILJ/0614",
    "name": "Iye-Ekiti Motor Park",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.954779,
    "lng": 5.318038
  },
  {
    "code": "EKS/ILJ/0615",
    "name": "Iye-Ekiti Youth Centre",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.951594,
    "lng": 5.367675
  },
  {
    "code": "EKS/ILJ/0616",
    "name": "Iye-Ekiti Youth Centre",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.895704,
    "lng": 5.376508
  },
  {
    "code": "EKS/ILJ/0617",
    "name": "Iye-Ekiti Motor Park",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.890014,
    "lng": 5.324226
  },
  {
    "code": "EKS/ILJ/0618",
    "name": "Iye-Ekiti Open Field",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.887474,
    "lng": 5.351279
  },
  {
    "code": "EKS/ILJ/0619",
    "name": "Iye-Ekiti Council Hall",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.955329,
    "lng": 5.312336
  },
  {
    "code": "EKS/ILJ/0620",
    "name": "Iye-Ekiti Palace Premises",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.929958,
    "lng": 5.37216
  },
  {
    "code": "EKS/ILJ/0621",
    "name": "Iye-Ekiti Post Office",
    "ward": "Iye-Ekiti",
    "lga": "Ilejemeje",
    "lat": 7.947402,
    "lng": 5.345089
  },
  {
    "code": "EKS/ILJ/0622",
    "name": "Ilejemeje Ward 1 Secondary School",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.886498,
    "lng": 5.375884
  },
  {
    "code": "EKS/ILJ/0623",
    "name": "Ilejemeje Ward 1 Secondary School",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.926142,
    "lng": 5.35209
  },
  {
    "code": "EKS/ILJ/0624",
    "name": "Ilejemeje Ward 1 Primary School",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.925771,
    "lng": 5.349449
  },
  {
    "code": "EKS/ILJ/0625",
    "name": "Ilejemeje Ward 1 Youth Centre",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.919843,
    "lng": 5.350173
  },
  {
    "code": "EKS/ILJ/0626",
    "name": "Ilejemeje Ward 1 Market Square",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.931353,
    "lng": 5.324168
  },
  {
    "code": "EKS/ILJ/0627",
    "name": "Ilejemeje Ward 1 Youth Centre",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.944375,
    "lng": 5.354799
  },
  {
    "code": "EKS/ILJ/0628",
    "name": "Ilejemeje Ward 1 Community Centre",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.916284,
    "lng": 5.355089
  },
  {
    "code": "EKS/ILJ/0629",
    "name": "Ilejemeje Ward 1 Market Square",
    "ward": "Ilejemeje Ward 1",
    "lga": "Ilejemeje",
    "lat": 7.915168,
    "lng": 5.33874
  },
  {
    "code": "EKS/ILJ/0630",
    "name": "Ilejemeje Ward 2 Ward Office",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.928533,
    "lng": 5.325007
  },
  {
    "code": "EKS/ILJ/0631",
    "name": "Ilejemeje Ward 2 Palace Premises",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.905545,
    "lng": 5.379042
  },
  {
    "code": "EKS/ILJ/0632",
    "name": "Ilejemeje Ward 2 Palace Premises",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.95803,
    "lng": 5.310461
  },
  {
    "code": "EKS/ILJ/0633",
    "name": "Ilejemeje Ward 2 Market Square",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.921198,
    "lng": 5.308495
  },
  {
    "code": "EKS/ILJ/0634",
    "name": "Ilejemeje Ward 2 Market Square",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.917318,
    "lng": 5.321398
  },
  {
    "code": "EKS/ILJ/0635",
    "name": "Ilejemeje Ward 2 Health Centre",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.89127,
    "lng": 5.304048
  },
  {
    "code": "EKS/ILJ/0636",
    "name": "Ilejemeje Ward 2 Post Office",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.949133,
    "lng": 5.333451
  },
  {
    "code": "EKS/ILJ/0637",
    "name": "Ilejemeje Ward 2 Court Premises",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.952185,
    "lng": 5.365078
  },
  {
    "code": "EKS/ILJ/0638",
    "name": "Ilejemeje Ward 2 Secondary School",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.926215,
    "lng": 5.325017
  },
  {
    "code": "EKS/ILJ/0639",
    "name": "Ilejemeje Ward 2 Church Hall",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.892747,
    "lng": 5.379678
  },
  {
    "code": "EKS/ILJ/0640",
    "name": "Ilejemeje Ward 2 Primary School",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.919901,
    "lng": 5.324683
  },
  {
    "code": "EKS/ILJ/0641",
    "name": "Ilejemeje Ward 2 Church Hall",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.887204,
    "lng": 5.331459
  },
  {
    "code": "EKS/ILJ/0642",
    "name": "Ilejemeje Ward 2 Palace Premises",
    "ward": "Ilejemeje Ward 2",
    "lga": "Ilejemeje",
    "lat": 7.957335,
    "lng": 5.317212
  },
  {
    "code": "EKS/IF/0643",
    "name": "Irepodun Ward 1 Court Premises",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.744043,
    "lng": 5.249592
  },
  {
    "code": "EKS/IF/0644",
    "name": "Irepodun Ward 1 Youth Centre",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.807428,
    "lng": 5.263802
  },
  {
    "code": "EKS/IF/0645",
    "name": "Irepodun Ward 1 Health Centre",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.782935,
    "lng": 5.277774
  },
  {
    "code": "EKS/IF/0646",
    "name": "Irepodun Ward 1 Palace Premises",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.750715,
    "lng": 5.231158
  },
  {
    "code": "EKS/IF/0647",
    "name": "Irepodun Ward 1 Health Centre",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.801109,
    "lng": 5.239275
  },
  {
    "code": "EKS/IF/0648",
    "name": "Irepodun Ward 1 Palace Premises",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.744093,
    "lng": 5.254945
  },
  {
    "code": "EKS/IF/0649",
    "name": "Irepodun Ward 1 Motor Park",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.784258,
    "lng": 5.215883
  },
  {
    "code": "EKS/IF/0650",
    "name": "Irepodun Ward 1 Post Office",
    "ward": "Irepodun Ward 1",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.776028,
    "lng": 5.253989
  },
  {
    "code": "EKS/IF/0651",
    "name": "Irepodun Ward 2 Town Hall",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.794432,
    "lng": 5.219505
  },
  {
    "code": "EKS/IF/0652",
    "name": "Irepodun Ward 2 Palace Premises",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.771512,
    "lng": 5.273592
  },
  {
    "code": "EKS/IF/0653",
    "name": "Irepodun Ward 2 Community Centre",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.784627,
    "lng": 5.239249
  },
  {
    "code": "EKS/IF/0654",
    "name": "Irepodun Ward 2 Motor Park",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.755925,
    "lng": 5.25073
  },
  {
    "code": "EKS/IF/0655",
    "name": "Irepodun Ward 2 Ward Office",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.74322,
    "lng": 5.213113
  },
  {
    "code": "EKS/IF/0656",
    "name": "Irepodun Ward 2 Church Hall",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.766643,
    "lng": 5.2479
  },
  {
    "code": "EKS/IF/0657",
    "name": "Irepodun Ward 2 Community Centre",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.751915,
    "lng": 5.281451
  },
  {
    "code": "EKS/IF/0658",
    "name": "Irepodun Ward 2 Community Centre",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.766237,
    "lng": 5.259045
  },
  {
    "code": "EKS/IF/0659",
    "name": "Irepodun Ward 2 Post Office",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.771436,
    "lng": 5.25932
  },
  {
    "code": "EKS/IF/0660",
    "name": "Irepodun Ward 2 Post Office",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.763939,
    "lng": 5.23691
  },
  {
    "code": "EKS/IF/0661",
    "name": "Irepodun Ward 2 Open Field",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.780777,
    "lng": 5.249188
  },
  {
    "code": "EKS/IF/0662",
    "name": "Irepodun Ward 2 Palace Premises",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.763983,
    "lng": 5.27526
  },
  {
    "code": "EKS/IF/0663",
    "name": "Irepodun Ward 2 Health Centre",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.766499,
    "lng": 5.218768
  },
  {
    "code": "EKS/IF/0664",
    "name": "Irepodun Ward 2 Ward Office",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.786696,
    "lng": 5.27374
  },
  {
    "code": "EKS/IF/0665",
    "name": "Irepodun Ward 2 Open Field",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.809768,
    "lng": 5.260341
  },
  {
    "code": "EKS/IF/0666",
    "name": "Irepodun Ward 2 Secondary School",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.777967,
    "lng": 5.287366
  },
  {
    "code": "EKS/IF/0667",
    "name": "Irepodun Ward 2 Market Square",
    "ward": "Irepodun Ward 2",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.817765,
    "lng": 5.256278
  },
  {
    "code": "EKS/IF/0668",
    "name": "Ifelodun Ward Council Hall",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.786682,
    "lng": 5.223641
  },
  {
    "code": "EKS/IF/0669",
    "name": "Ifelodun Ward Health Centre",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.797695,
    "lng": 5.271968
  },
  {
    "code": "EKS/IF/0670",
    "name": "Ifelodun Ward Primary School",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.751822,
    "lng": 5.264458
  },
  {
    "code": "EKS/IF/0671",
    "name": "Ifelodun Ward Market Square",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.785806,
    "lng": 5.266042
  },
  {
    "code": "EKS/IF/0672",
    "name": "Ifelodun Ward Community Centre",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.741515,
    "lng": 5.235095
  },
  {
    "code": "EKS/IF/0673",
    "name": "Ifelodun Ward Motor Park",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.773037,
    "lng": 5.226311
  },
  {
    "code": "EKS/IF/0674",
    "name": "Ifelodun Ward Post Office",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.801998,
    "lng": 5.283642
  },
  {
    "code": "EKS/IF/0675",
    "name": "Ifelodun Ward Ward Office",
    "ward": "Ifelodun Ward",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.80787,
    "lng": 5.268192
  },
  {
    "code": "EKS/IF/0676",
    "name": "Ora Council Hall",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.781495,
    "lng": 5.254871
  },
  {
    "code": "EKS/IF/0677",
    "name": "Ora Community Centre",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.77827,
    "lng": 5.240146
  },
  {
    "code": "EKS/IF/0678",
    "name": "Ora Motor Park",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.776773,
    "lng": 5.25265
  },
  {
    "code": "EKS/IF/0679",
    "name": "Ora Ward Office",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.768343,
    "lng": 5.271759
  },
  {
    "code": "EKS/IF/0680",
    "name": "Ora Youth Centre",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.79446,
    "lng": 5.274292
  },
  {
    "code": "EKS/IF/0681",
    "name": "Ora Market Square",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.788806,
    "lng": 5.225381
  },
  {
    "code": "EKS/IF/0682",
    "name": "Ora Youth Centre",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.762321,
    "lng": 5.23388
  },
  {
    "code": "EKS/IF/0683",
    "name": "Ora Ward Office",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.801694,
    "lng": 5.266392
  },
  {
    "code": "EKS/IF/0684",
    "name": "Ora Palace Premises",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.796399,
    "lng": 5.235363
  },
  {
    "code": "EKS/IF/0685",
    "name": "Ora Ward Office",
    "ward": "Ora",
    "lga": "Irepodun/Ifelodun",
    "lat": 7.784839,
    "lng": 5.284759
  },
  {
    "code": "EKS/IS/0686",
    "name": "Ise Ward 1 Motor Park",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.563023,
    "lng": 5.425878
  },
  {
    "code": "EKS/IS/0687",
    "name": "Ise Ward 1 Post Office",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.570376,
    "lng": 5.458413
  },
  {
    "code": "EKS/IS/0688",
    "name": "Ise Ward 1 Community Centre",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.567611,
    "lng": 5.441845
  },
  {
    "code": "EKS/IS/0689",
    "name": "Ise Ward 1 Ward Office",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.563236,
    "lng": 5.40301
  },
  {
    "code": "EKS/IS/0690",
    "name": "Ise Ward 1 Council Hall",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.546322,
    "lng": 5.453921
  },
  {
    "code": "EKS/IS/0691",
    "name": "Ise Ward 1 Market Square",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.560516,
    "lng": 5.418326
  },
  {
    "code": "EKS/IS/0692",
    "name": "Ise Ward 1 Motor Park",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.606236,
    "lng": 5.401691
  },
  {
    "code": "EKS/IS/0693",
    "name": "Ise Ward 1 Open Field",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.595694,
    "lng": 5.390982
  },
  {
    "code": "EKS/IS/0694",
    "name": "Ise Ward 1 Primary School",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.599271,
    "lng": 5.399143
  },
  {
    "code": "EKS/IS/0695",
    "name": "Ise Ward 1 Council Hall",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.593587,
    "lng": 5.422483
  },
  {
    "code": "EKS/IS/0696",
    "name": "Ise Ward 1 Palace Premises",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.558627,
    "lng": 5.388016
  },
  {
    "code": "EKS/IS/0697",
    "name": "Ise Ward 1 Secondary School",
    "ward": "Ise Ward 1",
    "lga": "Ise/Orun",
    "lat": 7.597389,
    "lng": 5.388044
  },
  {
    "code": "EKS/IS/0698",
    "name": "Ise Ward 2 Court Premises",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.540415,
    "lng": 5.424028
  },
  {
    "code": "EKS/IS/0699",
    "name": "Ise Ward 2 Court Premises",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.552635,
    "lng": 5.432231
  },
  {
    "code": "EKS/IS/0700",
    "name": "Ise Ward 2 Market Square",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.610272,
    "lng": 5.418196
  },
  {
    "code": "EKS/IS/0701",
    "name": "Ise Ward 2 Youth Centre",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.600473,
    "lng": 5.40298
  },
  {
    "code": "EKS/IS/0702",
    "name": "Ise Ward 2 Town Hall",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.591672,
    "lng": 5.452635
  },
  {
    "code": "EKS/IS/0703",
    "name": "Ise Ward 2 Ward Office",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.592184,
    "lng": 5.398578
  },
  {
    "code": "EKS/IS/0704",
    "name": "Ise Ward 2 Court Premises",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.597849,
    "lng": 5.454934
  },
  {
    "code": "EKS/IS/0705",
    "name": "Ise Ward 2 Post Office",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.613718,
    "lng": 5.413431
  },
  {
    "code": "EKS/IS/0706",
    "name": "Ise Ward 2 Post Office",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.554063,
    "lng": 5.453571
  },
  {
    "code": "EKS/IS/0707",
    "name": "Ise Ward 2 Court Premises",
    "ward": "Ise Ward 2",
    "lga": "Ise/Orun",
    "lat": 7.57176,
    "lng": 5.419631
  },
  {
    "code": "EKS/IS/0708",
    "name": "Orun Ward Open Field",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.610139,
    "lng": 5.380741
  },
  {
    "code": "EKS/IS/0709",
    "name": "Orun Ward Palace Premises",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.588223,
    "lng": 5.454276
  },
  {
    "code": "EKS/IS/0710",
    "name": "Orun Ward Motor Park",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.562765,
    "lng": 5.459128
  },
  {
    "code": "EKS/IS/0711",
    "name": "Orun Ward Community Centre",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.581945,
    "lng": 5.451141
  },
  {
    "code": "EKS/IS/0712",
    "name": "Orun Ward Market Square",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.608085,
    "lng": 5.417442
  },
  {
    "code": "EKS/IS/0713",
    "name": "Orun Ward Ward Office",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.604705,
    "lng": 5.406455
  },
  {
    "code": "EKS/IS/0714",
    "name": "Orun Ward Community Centre",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.576713,
    "lng": 5.400581
  },
  {
    "code": "EKS/IS/0715",
    "name": "Orun Ward Youth Centre",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.541127,
    "lng": 5.406969
  },
  {
    "code": "EKS/IS/0716",
    "name": "Orun Ward Community Centre",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.585422,
    "lng": 5.440583
  },
  {
    "code": "EKS/IS/0717",
    "name": "Orun Ward Health Centre",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.588876,
    "lng": 5.431098
  },
  {
    "code": "EKS/IS/0718",
    "name": "Orun Ward Town Hall",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.606159,
    "lng": 5.421222
  },
  {
    "code": "EKS/IS/0719",
    "name": "Orun Ward Community Centre",
    "ward": "Orun Ward",
    "lga": "Ise/Orun",
    "lat": 7.572067,
    "lng": 5.387631
  },
  {
    "code": "EKS/IS/0720",
    "name": "Oke-Agbe Youth Centre",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.565888,
    "lng": 5.399844
  },
  {
    "code": "EKS/IS/0721",
    "name": "Oke-Agbe Youth Centre",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.570686,
    "lng": 5.415739
  },
  {
    "code": "EKS/IS/0722",
    "name": "Oke-Agbe Ward Office",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.616323,
    "lng": 5.404156
  },
  {
    "code": "EKS/IS/0723",
    "name": "Oke-Agbe Palace Premises",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.58583,
    "lng": 5.400924
  },
  {
    "code": "EKS/IS/0724",
    "name": "Oke-Agbe Town Hall",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.595421,
    "lng": 5.38497
  },
  {
    "code": "EKS/IS/0725",
    "name": "Oke-Agbe Council Hall",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.577232,
    "lng": 5.392777
  },
  {
    "code": "EKS/IS/0726",
    "name": "Oke-Agbe Ward Office",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.580202,
    "lng": 5.451609
  },
  {
    "code": "EKS/IS/0727",
    "name": "Oke-Agbe Council Hall",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.601587,
    "lng": 5.435223
  },
  {
    "code": "EKS/IS/0728",
    "name": "Oke-Agbe Open Field",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.61329,
    "lng": 5.403603
  },
  {
    "code": "EKS/IS/0729",
    "name": "Oke-Agbe Church Hall",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.557668,
    "lng": 5.456589
  },
  {
    "code": "EKS/IS/0730",
    "name": "Oke-Agbe Open Field",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.552255,
    "lng": 5.439819
  },
  {
    "code": "EKS/IS/0731",
    "name": "Oke-Agbe Court Premises",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.56989,
    "lng": 5.436155
  },
  {
    "code": "EKS/IS/0732",
    "name": "Oke-Agbe Council Hall",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.577666,
    "lng": 5.423001
  },
  {
    "code": "EKS/IS/0733",
    "name": "Oke-Agbe Council Hall",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.606048,
    "lng": 5.440949
  },
  {
    "code": "EKS/IS/0734",
    "name": "Oke-Agbe Town Hall",
    "ward": "Oke-Agbe",
    "lga": "Ise/Orun",
    "lat": 7.600379,
    "lng": 5.449851
  },
  {
    "code": "EKS/MB/0735",
    "name": "Moba Ward 1 Town Hall",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.82974,
    "lng": 5.466401
  },
  {
    "code": "EKS/MB/0736",
    "name": "Moba Ward 1 Post Office",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.86738,
    "lng": 5.419077
  },
  {
    "code": "EKS/MB/0737",
    "name": "Moba Ward 1 Open Field",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.837812,
    "lng": 5.450539
  },
  {
    "code": "EKS/MB/0738",
    "name": "Moba Ward 1 Post Office",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.836933,
    "lng": 5.423263
  },
  {
    "code": "EKS/MB/0739",
    "name": "Moba Ward 1 Market Square",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.835627,
    "lng": 5.419399
  },
  {
    "code": "EKS/MB/0740",
    "name": "Moba Ward 1 Court Premises",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.851353,
    "lng": 5.449206
  },
  {
    "code": "EKS/MB/0741",
    "name": "Moba Ward 1 Church Hall",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.83483,
    "lng": 5.474795
  },
  {
    "code": "EKS/MB/0742",
    "name": "Moba Ward 1 Open Field",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.804556,
    "lng": 5.443334
  },
  {
    "code": "EKS/MB/0743",
    "name": "Moba Ward 1 Secondary School",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.798619,
    "lng": 5.44709
  },
  {
    "code": "EKS/MB/0744",
    "name": "Moba Ward 1 Youth Centre",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.818654,
    "lng": 5.411842
  },
  {
    "code": "EKS/MB/0745",
    "name": "Moba Ward 1 Open Field",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.859316,
    "lng": 5.469764
  },
  {
    "code": "EKS/MB/0746",
    "name": "Moba Ward 1 Ward Office",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.799842,
    "lng": 5.443996
  },
  {
    "code": "EKS/MB/0747",
    "name": "Moba Ward 1 Court Premises",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.799101,
    "lng": 5.48963
  },
  {
    "code": "EKS/MB/0748",
    "name": "Moba Ward 1 Church Hall",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.865537,
    "lng": 5.488991
  },
  {
    "code": "EKS/MB/0749",
    "name": "Moba Ward 1 Secondary School",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.796539,
    "lng": 5.442809
  },
  {
    "code": "EKS/MB/0750",
    "name": "Moba Ward 1 Ward Office",
    "ward": "Moba Ward 1",
    "lga": "Moba",
    "lat": 7.804834,
    "lng": 5.461422
  },
  {
    "code": "EKS/MB/0751",
    "name": "Moba Ward 2 Court Premises",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.871103,
    "lng": 5.440057
  },
  {
    "code": "EKS/MB/0752",
    "name": "Moba Ward 2 Court Premises",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.824598,
    "lng": 5.47967
  },
  {
    "code": "EKS/MB/0753",
    "name": "Moba Ward 2 Council Hall",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.8242,
    "lng": 5.41652
  },
  {
    "code": "EKS/MB/0754",
    "name": "Moba Ward 2 Post Office",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.863964,
    "lng": 5.420739
  },
  {
    "code": "EKS/MB/0755",
    "name": "Moba Ward 2 Motor Park",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.821822,
    "lng": 5.424378
  },
  {
    "code": "EKS/MB/0756",
    "name": "Moba Ward 2 Market Square",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.825445,
    "lng": 5.420288
  },
  {
    "code": "EKS/MB/0757",
    "name": "Moba Ward 2 Youth Centre",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.860786,
    "lng": 5.470594
  },
  {
    "code": "EKS/MB/0758",
    "name": "Moba Ward 2 Health Centre",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.83104,
    "lng": 5.467628
  },
  {
    "code": "EKS/MB/0759",
    "name": "Moba Ward 2 Market Square",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.836555,
    "lng": 5.475969
  },
  {
    "code": "EKS/MB/0760",
    "name": "Moba Ward 2 Market Square",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.83085,
    "lng": 5.42251
  },
  {
    "code": "EKS/MB/0761",
    "name": "Moba Ward 2 Town Hall",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.868993,
    "lng": 5.468102
  },
  {
    "code": "EKS/MB/0762",
    "name": "Moba Ward 2 Open Field",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.796577,
    "lng": 5.462916
  },
  {
    "code": "EKS/MB/0763",
    "name": "Moba Ward 2 Primary School",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.855284,
    "lng": 5.480801
  },
  {
    "code": "EKS/MB/0764",
    "name": "Moba Ward 2 Open Field",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.813253,
    "lng": 5.415483
  },
  {
    "code": "EKS/MB/0765",
    "name": "Moba Ward 2 Ward Office",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.796686,
    "lng": 5.457923
  },
  {
    "code": "EKS/MB/0766",
    "name": "Moba Ward 2 Primary School",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.863777,
    "lng": 5.429679
  },
  {
    "code": "EKS/MB/0767",
    "name": "Moba Ward 2 Market Square",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.826181,
    "lng": 5.428847
  },
  {
    "code": "EKS/MB/0768",
    "name": "Moba Ward 2 Community Centre",
    "ward": "Moba Ward 2",
    "lga": "Moba",
    "lat": 7.854351,
    "lng": 5.472185
  },
  {
    "code": "EKS/MB/0769",
    "name": "Ikun Court Premises",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.873479,
    "lng": 5.428833
  },
  {
    "code": "EKS/MB/0770",
    "name": "Ikun Open Field",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.852521,
    "lng": 5.435612
  },
  {
    "code": "EKS/MB/0771",
    "name": "Ikun Market Square",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.855803,
    "lng": 5.475571
  },
  {
    "code": "EKS/MB/0772",
    "name": "Ikun Council Hall",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.818141,
    "lng": 5.421561
  },
  {
    "code": "EKS/MB/0773",
    "name": "Ikun Youth Centre",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.8357,
    "lng": 5.443185
  },
  {
    "code": "EKS/MB/0774",
    "name": "Ikun Court Premises",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.798877,
    "lng": 5.485982
  },
  {
    "code": "EKS/MB/0775",
    "name": "Ikun Council Hall",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.852817,
    "lng": 5.424111
  },
  {
    "code": "EKS/MB/0776",
    "name": "Ikun Palace Premises",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.828176,
    "lng": 5.44975
  },
  {
    "code": "EKS/MB/0777",
    "name": "Ikun Secondary School",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.869327,
    "lng": 5.463807
  },
  {
    "code": "EKS/MB/0778",
    "name": "Ikun Health Centre",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.835957,
    "lng": 5.465805
  },
  {
    "code": "EKS/MB/0779",
    "name": "Ikun Secondary School",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.805937,
    "lng": 5.440217
  },
  {
    "code": "EKS/MB/0780",
    "name": "Ikun Market Square",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.837034,
    "lng": 5.429377
  },
  {
    "code": "EKS/MB/0781",
    "name": "Ikun Secondary School",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.818059,
    "lng": 5.466706
  },
  {
    "code": "EKS/MB/0782",
    "name": "Ikun Health Centre",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.831042,
    "lng": 5.41471
  },
  {
    "code": "EKS/MB/0783",
    "name": "Ikun Community Centre",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.871423,
    "lng": 5.454683
  },
  {
    "code": "EKS/MB/0784",
    "name": "Ikun Palace Premises",
    "ward": "Ikun",
    "lga": "Moba",
    "lat": 7.825074,
    "lng": 5.4305
  },
  {
    "code": "EKS/MB/0785",
    "name": "Otun Palace Premises",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.800326,
    "lng": 5.446083
  },
  {
    "code": "EKS/MB/0786",
    "name": "Otun Market Square",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.801397,
    "lng": 5.468067
  },
  {
    "code": "EKS/MB/0787",
    "name": "Otun Open Field",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.798123,
    "lng": 5.440273
  },
  {
    "code": "EKS/MB/0788",
    "name": "Otun Market Square",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.842234,
    "lng": 5.47999
  },
  {
    "code": "EKS/MB/0789",
    "name": "Otun Council Hall",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.858372,
    "lng": 5.457107
  },
  {
    "code": "EKS/MB/0790",
    "name": "Otun Post Office",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.838708,
    "lng": 5.448452
  },
  {
    "code": "EKS/MB/0791",
    "name": "Otun Court Premises",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.866563,
    "lng": 5.434355
  },
  {
    "code": "EKS/MB/0792",
    "name": "Otun Ward Office",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.795227,
    "lng": 5.485073
  },
  {
    "code": "EKS/MB/0793",
    "name": "Otun Church Hall",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.803385,
    "lng": 5.490066
  },
  {
    "code": "EKS/MB/0794",
    "name": "Otun Ward Office",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.867155,
    "lng": 5.46575
  },
  {
    "code": "EKS/MB/0795",
    "name": "Otun Motor Park",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.810361,
    "lng": 5.48331
  },
  {
    "code": "EKS/MB/0796",
    "name": "Otun Church Hall",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.819729,
    "lng": 5.432745
  },
  {
    "code": "EKS/MB/0797",
    "name": "Otun Youth Centre",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.836692,
    "lng": 5.438841
  },
  {
    "code": "EKS/MB/0798",
    "name": "Otun Church Hall",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.822772,
    "lng": 5.480725
  },
  {
    "code": "EKS/MB/0799",
    "name": "Otun Church Hall",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.801889,
    "lng": 5.488605
  },
  {
    "code": "EKS/MB/0800",
    "name": "Otun Market Square",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.85493,
    "lng": 5.435719
  },
  {
    "code": "EKS/MB/0801",
    "name": "Otun Open Field",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.823656,
    "lng": 5.443214
  },
  {
    "code": "EKS/MB/0802",
    "name": "Otun Primary School",
    "ward": "Otun",
    "lga": "Moba",
    "lat": 7.863127,
    "lng": 5.4694
  },
  {
    "code": "EKS/OY/0803",
    "name": "Oye Ward 1 Ward Office",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.754365,
    "lng": 5.326823
  },
  {
    "code": "EKS/OY/0804",
    "name": "Oye Ward 1 Palace Premises",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.743506,
    "lng": 5.292293
  },
  {
    "code": "EKS/OY/0805",
    "name": "Oye Ward 1 Market Square",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.728501,
    "lng": 5.325683
  },
  {
    "code": "EKS/OY/0806",
    "name": "Oye Ward 1 Council Hall",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.750044,
    "lng": 5.332469
  },
  {
    "code": "EKS/OY/0807",
    "name": "Oye Ward 1 Church Hall",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.737105,
    "lng": 5.341169
  },
  {
    "code": "EKS/OY/0808",
    "name": "Oye Ward 1 Church Hall",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.787421,
    "lng": 5.331436
  },
  {
    "code": "EKS/OY/0809",
    "name": "Oye Ward 1 Palace Premises",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.746966,
    "lng": 5.338722
  },
  {
    "code": "EKS/OY/0810",
    "name": "Oye Ward 1 Church Hall",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.723641,
    "lng": 5.337725
  },
  {
    "code": "EKS/OY/0811",
    "name": "Oye Ward 1 Council Hall",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.724824,
    "lng": 5.351249
  },
  {
    "code": "EKS/OY/0812",
    "name": "Oye Ward 1 Post Office",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.786679,
    "lng": 5.322016
  },
  {
    "code": "EKS/OY/0813",
    "name": "Oye Ward 1 Council Hall",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.777836,
    "lng": 5.355715
  },
  {
    "code": "EKS/OY/0814",
    "name": "Oye Ward 1 Community Centre",
    "ward": "Oye Ward 1",
    "lga": "Oye",
    "lat": 7.713981,
    "lng": 5.280611
  },
  {
    "code": "EKS/OY/0815",
    "name": "Oye Ward 2 Primary School",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.728615,
    "lng": 5.336674
  },
  {
    "code": "EKS/OY/0816",
    "name": "Oye Ward 2 Primary School",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.727598,
    "lng": 5.316581
  },
  {
    "code": "EKS/OY/0817",
    "name": "Oye Ward 2 Open Field",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.759527,
    "lng": 5.33344
  },
  {
    "code": "EKS/OY/0818",
    "name": "Oye Ward 2 Primary School",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.78312,
    "lng": 5.332843
  },
  {
    "code": "EKS/OY/0819",
    "name": "Oye Ward 2 Primary School",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.710629,
    "lng": 5.324231
  },
  {
    "code": "EKS/OY/0820",
    "name": "Oye Ward 2 Motor Park",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.711438,
    "lng": 5.337875
  },
  {
    "code": "EKS/OY/0821",
    "name": "Oye Ward 2 Post Office",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.788298,
    "lng": 5.281471
  },
  {
    "code": "EKS/OY/0822",
    "name": "Oye Ward 2 Court Premises",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.765929,
    "lng": 5.314546
  },
  {
    "code": "EKS/OY/0823",
    "name": "Oye Ward 2 Motor Park",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.724441,
    "lng": 5.353544
  },
  {
    "code": "EKS/OY/0824",
    "name": "Oye Ward 2 Motor Park",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.722012,
    "lng": 5.295455
  },
  {
    "code": "EKS/OY/0825",
    "name": "Oye Ward 2 Secondary School",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.730293,
    "lng": 5.308455
  },
  {
    "code": "EKS/OY/0826",
    "name": "Oye Ward 2 Health Centre",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.741852,
    "lng": 5.309944
  },
  {
    "code": "EKS/OY/0827",
    "name": "Oye Ward 2 Ward Office",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.74682,
    "lng": 5.299557
  },
  {
    "code": "EKS/OY/0828",
    "name": "Oye Ward 2 Post Office",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.728169,
    "lng": 5.334823
  },
  {
    "code": "EKS/OY/0829",
    "name": "Oye Ward 2 Council Hall",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.716549,
    "lng": 5.359434
  },
  {
    "code": "EKS/OY/0830",
    "name": "Oye Ward 2 Health Centre",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.770867,
    "lng": 5.28758
  },
  {
    "code": "EKS/OY/0831",
    "name": "Oye Ward 2 Council Hall",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.740274,
    "lng": 5.31818
  },
  {
    "code": "EKS/OY/0832",
    "name": "Oye Ward 2 Church Hall",
    "ward": "Oye Ward 2",
    "lga": "Oye",
    "lat": 7.710856,
    "lng": 5.293811
  },
  {
    "code": "EKS/OY/0833",
    "name": "Iye-Ekiti Post Office",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.761693,
    "lng": 5.306602
  },
  {
    "code": "EKS/OY/0834",
    "name": "Iye-Ekiti Court Premises",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.788007,
    "lng": 5.351683
  },
  {
    "code": "EKS/OY/0835",
    "name": "Iye-Ekiti Post Office",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.713504,
    "lng": 5.297013
  },
  {
    "code": "EKS/OY/0836",
    "name": "Iye-Ekiti Youth Centre",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.765483,
    "lng": 5.325443
  },
  {
    "code": "EKS/OY/0837",
    "name": "Iye-Ekiti Court Premises",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.713825,
    "lng": 5.286048
  },
  {
    "code": "EKS/OY/0838",
    "name": "Iye-Ekiti Council Hall",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.73253,
    "lng": 5.323542
  },
  {
    "code": "EKS/OY/0839",
    "name": "Iye-Ekiti Palace Premises",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.712732,
    "lng": 5.354401
  },
  {
    "code": "EKS/OY/0840",
    "name": "Iye-Ekiti Community Centre",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.711353,
    "lng": 5.296673
  },
  {
    "code": "EKS/OY/0841",
    "name": "Iye-Ekiti Health Centre",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.77028,
    "lng": 5.337117
  },
  {
    "code": "EKS/OY/0842",
    "name": "Iye-Ekiti Open Field",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.78441,
    "lng": 5.304042
  },
  {
    "code": "EKS/OY/0843",
    "name": "Iye-Ekiti Health Centre",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.729338,
    "lng": 5.346872
  },
  {
    "code": "EKS/OY/0844",
    "name": "Iye-Ekiti Health Centre",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.764263,
    "lng": 5.323345
  },
  {
    "code": "EKS/OY/0845",
    "name": "Iye-Ekiti Ward Office",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.770549,
    "lng": 5.291296
  },
  {
    "code": "EKS/OY/0846",
    "name": "Iye-Ekiti Palace Premises",
    "ward": "Iye-Ekiti",
    "lga": "Oye",
    "lat": 7.768033,
    "lng": 5.320163
  },
  {
    "code": "EKS/OY/0847",
    "name": "Ikole Ward Town Hall",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.717915,
    "lng": 5.298672
  },
  {
    "code": "EKS/OY/0848",
    "name": "Ikole Ward Open Field",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.737347,
    "lng": 5.34162
  },
  {
    "code": "EKS/OY/0849",
    "name": "Ikole Ward Primary School",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.741836,
    "lng": 5.341984
  },
  {
    "code": "EKS/OY/0850",
    "name": "Ikole Ward Church Hall",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.76083,
    "lng": 5.342784
  },
  {
    "code": "EKS/OY/0851",
    "name": "Ikole Ward Health Centre",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.749348,
    "lng": 5.308565
  },
  {
    "code": "EKS/OY/0852",
    "name": "Ikole Ward Council Hall",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.744648,
    "lng": 5.334476
  },
  {
    "code": "EKS/OY/0853",
    "name": "Ikole Ward Youth Centre",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.740506,
    "lng": 5.341873
  },
  {
    "code": "EKS/OY/0854",
    "name": "Ikole Ward Town Hall",
    "ward": "Ikole Ward",
    "lga": "Oye",
    "lat": 7.773944,
    "lng": 5.337149
  },
  {
    "code": "EKS/EF/0855",
    "name": "Efon Ward 1 Council Hall",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.632338,
    "lng": 4.996934
  },
  {
    "code": "EKS/EF/0856",
    "name": "Efon Ward 1 Palace Premises",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.632342,
    "lng": 4.97117
  },
  {
    "code": "EKS/EF/0857",
    "name": "Efon Ward 1 Youth Centre",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.628524,
    "lng": 4.940416
  },
  {
    "code": "EKS/EF/0858",
    "name": "Efon Ward 1 Town Hall",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.655579,
    "lng": 5.000908
  },
  {
    "code": "EKS/EF/0859",
    "name": "Efon Ward 1 Church Hall",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.630601,
    "lng": 4.954991
  },
  {
    "code": "EKS/EF/0860",
    "name": "Efon Ward 1 Town Hall",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.664559,
    "lng": 4.980995
  },
  {
    "code": "EKS/EF/0861",
    "name": "Efon Ward 1 Town Hall",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.622101,
    "lng": 4.968313
  },
  {
    "code": "EKS/EF/0862",
    "name": "Efon Ward 1 Post Office",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.667754,
    "lng": 5.002755
  },
  {
    "code": "EKS/EF/0863",
    "name": "Efon Ward 1 Health Centre",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.650819,
    "lng": 4.963348
  },
  {
    "code": "EKS/EF/0864",
    "name": "Efon Ward 1 Motor Park",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.682334,
    "lng": 4.997988
  },
  {
    "code": "EKS/EF/0865",
    "name": "Efon Ward 1 Open Field",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.692417,
    "lng": 5.018254
  },
  {
    "code": "EKS/EF/0866",
    "name": "Efon Ward 1 Community Centre",
    "ward": "Efon Ward 1",
    "lga": "Efon",
    "lat": 7.661688,
    "lng": 4.994825
  },
  {
    "code": "EKS/EF/0867",
    "name": "Efon Ward 2 Community Centre",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.641514,
    "lng": 4.961473
  },
  {
    "code": "EKS/EF/0868",
    "name": "Efon Ward 2 Health Centre",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.625061,
    "lng": 4.974774
  },
  {
    "code": "EKS/EF/0869",
    "name": "Efon Ward 2 Palace Premises",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.64398,
    "lng": 5.002613
  },
  {
    "code": "EKS/EF/0870",
    "name": "Efon Ward 2 Council Hall",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.640136,
    "lng": 4.959727
  },
  {
    "code": "EKS/EF/0871",
    "name": "Efon Ward 2 Church Hall",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.659664,
    "lng": 4.989334
  },
  {
    "code": "EKS/EF/0872",
    "name": "Efon Ward 2 Health Centre",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.628558,
    "lng": 4.964373
  },
  {
    "code": "EKS/EF/0873",
    "name": "Efon Ward 2 Secondary School",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.646577,
    "lng": 4.989615
  },
  {
    "code": "EKS/EF/0874",
    "name": "Efon Ward 2 Health Centre",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.688976,
    "lng": 4.975218
  },
  {
    "code": "EKS/EF/0875",
    "name": "Efon Ward 2 Open Field",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.685238,
    "lng": 5.008761
  },
  {
    "code": "EKS/EF/0876",
    "name": "Efon Ward 2 Ward Office",
    "ward": "Efon Ward 2",
    "lga": "Efon",
    "lat": 7.63089,
    "lng": 4.965653
  },
  {
    "code": "EKS/EF/0877",
    "name": "Aramoko Health Centre",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.658321,
    "lng": 4.954211
  },
  {
    "code": "EKS/EF/0878",
    "name": "Aramoko Ward Office",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.697498,
    "lng": 4.963316
  },
  {
    "code": "EKS/EF/0879",
    "name": "Aramoko Secondary School",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.670632,
    "lng": 5.017421
  },
  {
    "code": "EKS/EF/0880",
    "name": "Aramoko Post Office",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.639394,
    "lng": 4.970084
  },
  {
    "code": "EKS/EF/0881",
    "name": "Aramoko Court Premises",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.682869,
    "lng": 4.969201
  },
  {
    "code": "EKS/EF/0882",
    "name": "Aramoko Motor Park",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.665108,
    "lng": 4.987378
  },
  {
    "code": "EKS/EF/0883",
    "name": "Aramoko Primary School",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.634394,
    "lng": 5.001409
  },
  {
    "code": "EKS/EF/0884",
    "name": "Aramoko Ward Office",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.69624,
    "lng": 4.97693
  },
  {
    "code": "EKS/EF/0885",
    "name": "Aramoko Post Office",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.636772,
    "lng": 5.003815
  },
  {
    "code": "EKS/EF/0886",
    "name": "Aramoko Secondary School",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.675427,
    "lng": 5.005517
  },
  {
    "code": "EKS/EF/0887",
    "name": "Aramoko Community Centre",
    "ward": "Aramoko",
    "lga": "Efon",
    "lat": 7.683604,
    "lng": 4.993838
  },
  {
    "code": "EKS/EF/0888",
    "name": "Oke-Efon Community Centre",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.644227,
    "lng": 4.960215
  },
  {
    "code": "EKS/EF/0889",
    "name": "Oke-Efon Town Hall",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.677219,
    "lng": 5.003126
  },
  {
    "code": "EKS/EF/0890",
    "name": "Oke-Efon Open Field",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.655925,
    "lng": 4.987835
  },
  {
    "code": "EKS/EF/0891",
    "name": "Oke-Efon Court Premises",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.652064,
    "lng": 4.980529
  },
  {
    "code": "EKS/EF/0892",
    "name": "Oke-Efon Primary School",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.689571,
    "lng": 4.973464
  },
  {
    "code": "EKS/EF/0893",
    "name": "Oke-Efon Court Premises",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.683258,
    "lng": 4.968762
  },
  {
    "code": "EKS/EF/0894",
    "name": "Oke-Efon Court Premises",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.684984,
    "lng": 4.987506
  },
  {
    "code": "EKS/EF/0895",
    "name": "Oke-Efon Council Hall",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.626799,
    "lng": 5.001516
  },
  {
    "code": "EKS/EF/0896",
    "name": "Oke-Efon Open Field",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.673176,
    "lng": 4.953307
  },
  {
    "code": "EKS/EF/0897",
    "name": "Oke-Efon Council Hall",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.623544,
    "lng": 5.018689
  },
  {
    "code": "EKS/EF/0898",
    "name": "Oke-Efon Palace Premises",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.671739,
    "lng": 5.017345
  },
  {
    "code": "EKS/EF/0899",
    "name": "Oke-Efon Primary School",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.697257,
    "lng": 4.974436
  },
  {
    "code": "EKS/EF/0900",
    "name": "Oke-Efon Ward Office",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.627889,
    "lng": 4.95776
  },
  {
    "code": "EKS/EF/0901",
    "name": "Oke-Efon Open Field",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.661504,
    "lng": 4.986441
  },
  {
    "code": "EKS/EF/0902",
    "name": "Oke-Efon Church Hall",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.637683,
    "lng": 4.96993
  },
  {
    "code": "EKS/EF/0903",
    "name": "Oke-Efon Motor Park",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.681787,
    "lng": 4.987087
  },
  {
    "code": "EKS/EF/0904",
    "name": "Oke-Efon Church Hall",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.63206,
    "lng": 5.019816
  },
  {
    "code": "EKS/EF/0905",
    "name": "Oke-Efon Town Hall",
    "ward": "Oke-Efon",
    "lga": "Efon",
    "lat": 7.628364,
    "lng": 4.973278
  }
];

if (typeof module !== 'undefined') module.exports = { ALL_POLLING_UNITS };
