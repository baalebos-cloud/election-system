// ============================================================
//  js/map.js
//  Leaflet map init, GPS handler, manual coord entry,
//  dashboard map, polling unit marker rendering
// ============================================================

let dashMap = null;
let pickerMap = null;
let pickerMarker = null;
let pickedLat = null;
let pickedLng = null;

// ── DASHBOARD MAP ─────────────────────────────────────────
function initDashMap() {
  if (dashMap) { dashMap.invalidateSize(); return; }

  dashMap = L.map('dash-map', { zoomControl: true, scrollWheelZoom: false })
    .setView([7.72, 5.31], 9);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors', maxZoom: 18,
  }).addTo(dashMap);

  // Plot all 905 polling units
  ALL_POLLING_UNITS.forEach(u => {
    const reported = reportedResults[u.code];
    const circle = L.circleMarker([u.lat, u.lng], {
      radius: reported ? 8 : 4,
      fillColor: reported ? '#00B04F' : '#E8A020',
      color: '#fff', weight: 1.5, opacity: 1, fillOpacity: 0.85,
    }).addTo(dashMap);

    let popup = `<b>${u.code}</b><br>${u.name}<br>${u.ward} · ${u.lga}`;
    if (reported) {
      const top = Object.entries(reported.results).sort((a, b) => b[1] - a[1])[0];
      const p = PARTIES.find(p => p.id === top[0]);
      popup += `<br><span style="color:${p?.color};font-weight:600">Leading: ${p?.abbr} (${top[1].toLocaleString()})</span>`;
      if (reported.agentId) popup += `<br><small>Agent: ${reported.agentId}</small>`;
    } else {
      popup += `<br><span style="color:#E8A020">⏳ Awaiting results</span>`;
    }
    circle.bindPopup(popup);
  });

  // Map legend
  const legend = L.control({ position: 'bottomright' });
  legend.onAdd = function () {
    const d = L.DomUtil.create('div');
    d.style.cssText = 'background:#fff;padding:7px 10px;border-radius:8px;font-size:11px;box-shadow:0 2px 8px rgba(0,0,0,.15)';
    d.innerHTML = '<b style="display:block;margin-bottom:4px">Status</b>'
      + '<div style="display:flex;align-items:center;gap:5px;margin-bottom:2px"><div style="width:9px;height:9px;border-radius:50%;background:#00B04F"></div>Reported</div>'
      + '<div style="display:flex;align-items:center;gap:5px"><div style="width:6px;height:6px;border-radius:50%;background:#E8A020;margin-left:1px"></div>Pending</div>';
    return d;
  };
  legend.addTo(dashMap);
}

// ── AGENT GPS MAP PICKER ──────────────────────────────────
function openMapModal() {
  document.getElementById('map-modal').classList.add('open');

  requestAnimationFrame(() => {
    setTimeout(() => {
      if (pickerMap) {
        pickerMap.invalidateSize({ animate: false });
        if (agentPU) pickerMap.setView([agentPU.lat, agentPU.lng], 14);
        if (pickedLat !== null) {
          if (pickerMarker) pickerMarker.remove();
          pickerMarker = L.marker([pickedLat, pickedLng]).addTo(pickerMap);
        }
        return;
      }

      const center = agentPU ? [agentPU.lat, agentPU.lng] : [7.72, 5.31];
      const zoom   = agentPU ? 14 : 10;

      pickerMap = L.map('picker-map', { center, zoom, zoomControl: true, scrollWheelZoom: true });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors', maxZoom: 19,
      }).addTo(pickerMap);

      // Mark assigned unit in blue
      if (agentPU) {
        L.circleMarker([agentPU.lat, agentPU.lng], {
          radius: 10, fillColor: '#1A6FA8', color: '#fff',
          weight: 2, opacity: 1, fillOpacity: 0.8,
        }).bindPopup(`<b>${agentPU.code}</b><br>${agentPU.name}<br><i>Your assigned unit</i>`)
          .addTo(pickerMap).openPopup();
      }

      // Click-to-pin
      pickerMap.on('click', function (e) {
        pickedLat = e.latlng.lat;
        pickedLng = e.latlng.lng;
        if (pickerMarker) pickerMarker.remove();
        pickerMarker = L.marker([pickedLat, pickedLng])
          .addTo(pickerMap)
          .bindPopup('📍 Your reported position<br>' + pickedLat.toFixed(6) + ', ' + pickedLng.toFixed(6))
          .openPopup();
        document.getElementById('picked-coords').textContent =
          'Lat: ' + pickedLat.toFixed(6) + ', Lng: ' + pickedLng.toFixed(6);
      });

      setTimeout(() => pickerMap.invalidateSize({ animate: false }), 300);
    }, 80);
  });
}

function closeMapModal() {
  document.getElementById('map-modal').classList.remove('open');
  document.getElementById('manual-coord-panel').style.display = 'none';
  if (pickerMap) setTimeout(() => pickerMap.invalidateSize({ animate: false }), 50);
}

// ── GPS ACQUISITION ───────────────────────────────────────
function useGPS() {
  if (!navigator.geolocation) {
    showManualCoordPanel();
    toast('GPS not available — enter coordinates manually', 'warn');
    return;
  }

  toast('Requesting GPS location...', 'info');

  navigator.geolocation.getCurrentPosition(
    function (pos) {
      pickedLat = pos.coords.latitude;
      pickedLng = pos.coords.longitude;
      const acc = Math.round(pos.coords.accuracy);

      function plotGPS() {
        if (!pickerMap) { setTimeout(plotGPS, 200); return; }
        pickerMap.setView([pickedLat, pickedLng], 16);
        if (pickerMarker) pickerMarker.remove();
        pickerMarker = L.marker([pickedLat, pickedLng])
          .addTo(pickerMap)
          .bindPopup('📍 GPS · Accuracy ±' + acc + 'm<br>' + pickedLat.toFixed(6) + ', ' + pickedLng.toFixed(6))
          .openPopup();
        document.getElementById('picked-coords').textContent =
          'GPS — Lat: ' + pickedLat.toFixed(6) + ', Lng: ' + pickedLng.toFixed(6) + ' (±' + acc + 'm)';
        toast('GPS acquired (±' + acc + 'm)', 'ok');
      }
      plotGPS();
    },
    function (err) {
      const reasons = {
        1: 'GPS permission denied — use manual entry or click the map',
        2: 'GPS position unavailable — use manual entry or click the map',
        3: 'GPS timed out — use manual entry or click the map',
      };
      SEC.log('warn', 'GPS failed', 'Code: ' + err.code + ' — ' + err.message);
      showManualCoordPanel();
      if (agentPU) {
        document.getElementById('manual-lat').value = agentPU.lat.toFixed(6);
        document.getElementById('manual-lng').value = agentPU.lng.toFixed(6);
        document.getElementById('manual-coord-msg').textContent =
          'GPS unavailable. Pre-filled with your polling unit coordinates. Adjust if needed.';
        document.getElementById('manual-coord-msg').style.color = 'var(--gold)';
      }
      toast(reasons[err.code] || 'GPS failed — use manual entry', 'warn');
    },
    { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
  );
}

// ── MANUAL COORDINATE ENTRY ───────────────────────────────
function showManualCoordPanel() {
  document.getElementById('manual-coord-panel').style.display = 'block';
}

function applyManualCoords() {
  const lat = parseFloat(document.getElementById('manual-lat').value);
  const lng = parseFloat(document.getElementById('manual-lng').value);
  if (isNaN(lat) || isNaN(lng)) { toast('Enter valid decimal coordinates', 'err'); return; }
  if (lat < 6.5 || lat > 9.0 || lng < 4.0 || lng > 6.5) {
    toast('Coordinates appear outside Ekiti State — please verify', 'warn');
  }
  pickedLat = lat; pickedLng = lng;

  function plotManual() {
    if (!pickerMap) { setTimeout(plotManual, 200); return; }
    pickerMap.setView([pickedLat, pickedLng], 15);
    if (pickerMarker) pickerMarker.remove();
    pickerMarker = L.marker([pickedLat, pickedLng])
      .addTo(pickerMap)
      .bindPopup('📍 Manual — ' + pickedLat.toFixed(6) + ', ' + pickedLng.toFixed(6))
      .openPopup();
    document.getElementById('picked-coords').textContent =
      'Manual — Lat: ' + pickedLat.toFixed(6) + ', Lng: ' + pickedLng.toFixed(6);
  }
  plotManual();
  toast('Coordinates applied — click Confirm to save', 'ok');
}

function useUnitCoords() {
  if (!agentPU) { toast('Select a polling unit first', 'warn'); return; }
  document.getElementById('manual-lat').value = agentPU.lat.toFixed(6);
  document.getElementById('manual-lng').value = agentPU.lng.toFixed(6);
  applyManualCoords();
}

function confirmLoc() {
  if (pickedLat === null) { toast('Click the map or enter coordinates first', 'warn'); return; }
  closeMapModal();
  document.getElementById('loc-box').style.display   = 'flex';
  document.getElementById('map-btn').style.display   = 'none';
  document.getElementById('repick-btn').style.display = 'block';
  document.getElementById('loc-nm').textContent      = 'Location confirmed ✓';
  document.getElementById('loc-coords').textContent  = pickedLat.toFixed(6) + ', ' + pickedLng.toFixed(6);
  toast('Location confirmed and geo-tagged', 'ok');
  SEC.log('ok', 'GPS location confirmed', pickedLat.toFixed(6) + ', ' + pickedLng.toFixed(6));
}

function reopenMap() {
  document.getElementById('loc-box').style.display    = 'none';
  document.getElementById('map-btn').style.display    = 'flex';
  document.getElementById('repick-btn').style.display = 'none';
  openMapModal();
}
